import random

def printMatrix ( mas ):
    print()
    for i in mas:
        for i2 in i:
            print(i2, end=' ')
        print()
    print()

def raspl1(mas,p):
    matrix=[[]for i in range(len(mas[0]))]
    for j in range(len(mas)):
        rand=random.randint(0,len(mas[0])-1)
        matrix[rand].append(p[j])
    printMatrix(matrix)
    return matrix

def raspl2(mas,p):
    matrix=[[0]for i in range(len(mas[0]))]
    for i in range(len(p)):
        summ=[]
        for j in range(len(matrix)):

            summ.append(sum(matrix[j]))
        index_min=summ.index(min(summ))
        matrix[index_min].append(p[i])
    for i in range(len(matrix)):
        for j in matrix[i]:
            if j ==0:
                matrix[i].remove(j)
    printMatrix(matrix)
    return matrix

def raspl3(mas,p):
    matrix=[[] for i in range(len(mas[0]))]
    p1=[]
    for i in p:
        p1.append(i)
    i=0
    for j in range(len(p)):

        maxx=max(p1)
        matrix[i].append(maxx)
        p1.remove(maxx)
        i+=1
        if i==len(matrix):
            i=0
    printMatrix(matrix)
    return matrix

def kron(matrix):
    summ=[0 for i in range(len(matrix))]
    for i in range(len(matrix)):
        summ[i]=sum(matrix[i])
    print(summ)
    index_max=summ.index(max(summ))
    index_min=summ.index(min(summ))
    print(index_max,index_min)
    delta= max(summ)-min(summ)
    print(delta)
    for i in matrix[index_max]:
        if i < delta:
            print("------------$$$$$$$$$--------------------")
            matrix[index_min].append(i)
            matrix[index_max].remove(i)
            printMatrix(matrix)
            return kron(matrix)
           
    print("---------------$$$$$$------------------")
    for i in matrix[index_max]:
        for j in matrix[index_min]:
            if (i>j) and (i-j<delta):
                matrix[index_min].append(i)
                matrix[index_min].remove(j)
                matrix[index_max].remove(i)
                matrix[index_max].append(j)
                printMatrix(matrix)
                return kron(matrix)
    printMatrix(matrix)
    print("Суммы = ",summ)
    print("Дельта = ",delta)


n=5
m=12
t1=10
t2=12
p=[]
for i in range(m):
    p.append(random.randint(t1,t2))
mas = [[ 0 for j in range(n)] for i in range(m)]
for i in range(len(mas)):
    mas[i][0]=p[i]
for i in range(len(mas)):
    for j in range(len(mas[0])-1):
        mas[i][j+1]=mas[i][j]
printMatrix(mas)
print("\n\n")
print("Задание 1 ")
kron(raspl1(mas,p))
print("\n\nЗадание 2 ")
kron(raspl2(mas,p))
print("\n\nЗадание 3 ")
kron(raspl3(mas, p))
