import java.util.*;

public class Test {
    public static Map<Integer,String> operationsMap;
    public static Map<Integer, ArrayList<String>> userPermissionMap;
    public static String[][] arr;
    public static void main(String[] args) {
        setUserIntoArray();
        setPermissionsIntoMap();
        User user = userExist(getUserName());
        if(user!=null){
            System.out.println("login success , welcome "+user.getUsername());
            getUserPermissions(user);
            
            while (true){
                Object object = getNextOperation(user.getUsername());
                boolean havePermission = userHavePermission(user,object);
                if(havePermission && !object.getOperation().equals("grant")){
                    System.out.println("you have permission to "+object.getOperation()+" in this object");
                }else if(havePermission && object.getOperation().equals("grant")){
                    handleGrantOperation(object);
                }else{
                    System.out.println("you don't have permission to "+object.getOperation()+" in this object");
                }

            }
        }else System.out.println("user doesn't exist");
    }
    public static void setUserIntoArray(){
        arr = new String[][]{
            {"ahmed", "0", "4", "3"},
            {"said", "1", "4", "2"},
            {"hassan", "2", "1", "4"},
            {"mohamed", "1", "7", "4"},
            {"asma", "5", "7", "1"}
        };
    }
    public static void printArray(){
        for (int i = 0; i <arr.length ; i++) {
            for (int j = 0; j <arr[0].length; j++) {
                if (j==0){
                    System.out.print(arr[i][j] + "  ");
                }else{
                    int permission = Integer.parseInt(arr[i][j]);
                    System.out.print(" (  ");
                    for (int k = 0; k < userPermissionMap.get(permission).size(); k++) {
                        System.out.print(userPermissionMap.get(permission).get(k) + " ");
                    }
                    System.out.print(" ) ");
                }
            }
            System.out.println();
        }
    }
    public static User userExist(String s){
        for (int i = 0; i < arr.length; i++) {
            if(arr[i][0].equals(s)){
                return new User(s,i);
            }
        }
        return null;
    }
    public static String getUserName(){
        Scanner sc =new Scanner(System.in);
        System.out.println("UserName : ");
        return sc.nextLine();
    }
    public static void getUserPermissions(User user){
        System.out.println("List of your rights:");
        for (int j = 1; j < arr[0].length; j++) {
            System.out.print("object № "+ j +" : ");
            int permission = Integer.parseInt(arr[user.getPos()][j]);
            for (int i = 0; i < userPermissionMap.get(permission).size() ; i++) {
                System.out.print(userPermissionMap.get(permission).get(i) + " ");
            }
            System.out.println();
        }
    }
    public static Object getNextOperation(String m){
        Scanner sc = new Scanner(System.in);
        String operation ="";
        while (!operation.equals("quit")){
           System.out.println("waiting your operation");
            operation = sc.nextLine();
            boolean foundOperation =false;
        if(operation.equals("quit")){
            System.out.println("The work of the user "+ m +" is completed. Goodbye.");
            System.exit(0);
            return null;
       }else{
            if(operationExist(operation)){
                int objectId=-1;
                while (objectId<1 || objectId > arr[0].length){
                    System.out.println("choose which object");
                    objectId = sc.nextInt();
                    if(objectId < 1 || objectId > arr[0].length){
                        System.out.println("object id name is wrong");
                    }
                }
                return new Object(objectId,operation);
        }else System.out.println("wrong operation");

        }
    }
       return null;
    }
    public static void setPermissionsIntoMap(){
        operationsMap = new HashMap<Integer , String>();
        operationsMap.put(0,"blocked");
        operationsMap.put(1,"read");
        operationsMap.put(2,"write");
        operationsMap.put(3,"grant");

        userPermissionMap = new HashMap<Integer, ArrayList<String>>();
        userPermissionMap.put(0,new ArrayList<String>(Arrays.asList(operationsMap.get(0))));
        userPermissionMap.put(1,new ArrayList<String>(Arrays.asList(operationsMap.get(3))));
        userPermissionMap.put(2,new ArrayList<String>(Arrays.asList(operationsMap.get(2))));
        userPermissionMap.put(3,new ArrayList<String>(Arrays.asList(operationsMap.get(2), operationsMap.get(3))));
        userPermissionMap.put(4,new ArrayList<String>(Arrays.asList(operationsMap.get(1))));
        userPermissionMap.put(5,new ArrayList<String>(Arrays.asList(operationsMap.get(1), operationsMap.get(3))));
        userPermissionMap.put(6,new ArrayList<String>(Arrays.asList(operationsMap.get(1), operationsMap.get(2))));
        userPermissionMap.put(7,new ArrayList<String>(Arrays.asList(operationsMap.get(1), operationsMap.get(2), operationsMap.get(3))));
    }
    public static boolean userHavePermission(User user , Object object){
       int permission = Integer.parseInt(arr[user.getPos()][object.getId()]);
        for (int i = 0; i < userPermissionMap.get(permission).size(); i++) {
            if(object.getOperation().equals(userPermissionMap.get(permission).get(i)))
                return true;
        }
        return false;
    }
    public static void handleGrantOperation(Object object){
        Scanner sc = new Scanner(System.in);
        String operation="";
        while (!operationExist(operation)) {
            System.out.println("which operation you want to grant");
            operation = sc.nextLine();
        }
        System.out.println("Who is the user that you want to grant him '"+operation+"'");
        String username = sc.nextLine();
        User user = userExist(username);
        while (user == null){
            System.out.println("Who is the user that you want to grant him '"+operation+"'");
            username = sc.nextLine();
            user = userExist(username);
        }
        addPermission(user,object,operation);
    }
    public static void addPermission(User user , Object object , String operation){
        if (!userHavePermission(user,object,operation)){
            ArrayList<String>userPermissions =new ArrayList<>();
            userPermissions.add(operation);
            int permission =Integer.parseInt(arr[user.getPos()][object.getId()]);
            for (int i = 0; i < userPermissionMap.get(permission).size(); i++) {
                userPermissions.add(userPermissionMap.get(permission).get(i));
            }
            for (int i = 0; i < userPermissionMap.size(); i++) {
                if(userPermissionMap.get(i).size() == userPermissions.size()){
                    if(userPermissions.containsAll(userPermissionMap.get(i))){
                        arr[user.getPos()][object.getId()]=String.valueOf(i);
                        printArray();
                        break;
                    }
                }
            }


        }else System.out.println("user already have this permission");
    }
    public static boolean userHavePermission(User user , Object object , String operation){
        int permission =Integer.parseInt(arr[user.getPos()][object.getId()]);
        for (int i = 0; i < userPermissionMap.get(permission).size(); i++) {
            if(userPermissionMap.get(permission).get(i).equals(operation)){
                return true;
            }
        }
        return false;
    }
    public static boolean operationExist(String operation){
        for (int i = 0; i < operationsMap.size(); i++) {
            if(operation.equals(operationsMap.get(i))) {
                return true;
            }
        }
        return false;
    }
} 
