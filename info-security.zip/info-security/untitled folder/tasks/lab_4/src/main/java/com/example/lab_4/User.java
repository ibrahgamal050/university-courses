package com.example.lab_4;

public class User {
    public User(String username, int pos) {
        this.username = username;
        this.pos = pos;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", pos=" + pos +
                '}';
    }

    private String username;
    private int pos;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getPos() {
        return pos;
    }

    public void setPos(int pos) {
        this.pos = pos;
    }
}
