import java.math.BigInteger;

public class RSA2 {
    private BigInteger n, d, e;

    public RSA2(BigInteger p, BigInteger q) {
        BigInteger phi = (p.subtract(BigInteger.ONE)).multiply(q.subtract(BigInteger.ONE));
        n = p.multiply(q);
        e = BigInteger.valueOf(65537); // Commonly used public exponent
        d = e.modInverse(phi);
    }

    public BigInteger encrypt(BigInteger message) {
        return message.modPow(e, n);
    }

    public BigInteger decrypt(BigInteger message) {
        return message.modPow(d, n);
    }

    public static void main(String[] args) {
        BigInteger p = BigInteger.valueOf(13);
        BigInteger q = BigInteger.valueOf(61);

        RSA2 rsa = new RSA2(p, q);

        String message = "Kovalev";
        BigInteger plainText = BigInteger.valueOf(0);
        for (int i = 0; i < message.length(); i++) {
            int letterValue = (int) message.charAt(i) - 1040; // Convert letter to its numerical value
            plainText = plainText.multiply(BigInteger.valueOf(100)).add(BigInteger.valueOf(letterValue)); // Append numerical value to plaintext
        }

        BigInteger cipherText = rsa.encrypt(plainText);
        System.out.println("Encrypted message: " + cipherText);

        BigInteger decryptedText = rsa.decrypt(cipherText);
        StringBuilder decryptedMessage = new StringBuilder();
        while (decryptedText.compareTo(BigInteger.ZERO) > 0) {
            BigInteger remainder = decryptedText.mod(BigInteger.valueOf(100));
            char letter = (char) (remainder.intValue() + 1040); // Convert numerical value back to letter
            decryptedMessage.insert(0, letter);
            decryptedText = decryptedText.divide(BigInteger.valueOf(100));
        }
        System.out.println("Decrypted message: " + decryptedMessage.toString());
    }
}
