import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.stream.Stream;

public class CMP {
    static int row = 16;//m
    static int col = 5 ;//n

    public static void main(String[] args) {
        int[][] arr = generateArray();
        System.out.println("array before sorting");
        printArray(arr);
        arrangeArray(arr);
        System.out.println();
        System.out.println("array after sorting");
        printArray(arr);
        System.out.println(" ------------- ");
        ArrayList<int[]> arrayList = new ArrayList();
       // arrayList = test(arrayList,arr,0);
        printArray(arrayList);
        maxNumber(arrayList);
    }
    public static void maxNumber(ArrayList<int[]> arr){
        for (int i = 0; i < arr.size(); i++) {
            System.out.println("max in column " +(i+1) + " : " + Arrays.stream(arr.get(i)).max().getAsInt());
        }
    }
    public static ArrayList<int[]> test(ArrayList arrayList ,int[][] arr , int c){
        int [] p_arr = {0,0,0,0};
        for (int i = 0; i < p_arr.length; i++) {
            p_arr[i]= arr [i][c];
        }
        for (int i = 3; i < row; i++) {
            int pos = getSmallestNumberPosition(p_arr);
            p_arr[pos]+=arr[i][c];
        }
        arrayList.add(p_arr);
        if(c<col-1){
            return test(arrayList,arr,c+1);
        }
        return arrayList;
    }
    public static int getSmallestNumberPosition(int[] arr){
        int index = 0;
        int min = arr[index];
        for (int i = 1; i < arr.length; i++){
            if (arr[i] < min){
                min = arr[i];
                index = i;
            }
        }
        return index;
    }
    public static void arrangeArray(int[][] arr){
        int i, j, temp;
        for (int k = 0; k < col; ++k) {
            for (i = 0; i < row; ++i) {
                for (j = 0; j < row - 1 - i; ++j) {
                    if (arr[j][k] < arr[j + 1][k]) {
                        temp = arr[j + 1][k];
                        arr[j + 1][k] = arr[j][k];
                        arr[j][k] = temp;
                    }
                }
            }
        }
    }
    public static void printArray(int[][] arr){
        for (int i = 0; i < row; i++) {
            System.out.print("[");
            for (int j = 0; j < col; j++) {
                System.out.print(arr[i][j]);
                if(j != col-1) System.out.print(" , ");
            }
            System.out.print("]");
            System.out.println();
        }
    }
    public static void printArray(int[] arr){
        System.out.print("[");
        for (int j = 0; j < arr.length; j++) {
            System.out.print(arr[j]);
            if(j != arr.length-1) System.out.print(" , ");
        }
        System.out.print("]");
    }
    public static void printArray(ArrayList<int[]> arr){
        for (int i = 0; i < arr.size(); i++) {
            System.out.print("]");
            for (int j = 0; j < arr.get(i).length; j++) {
                System.out.print(arr.get(i)[j]);
                if(j != arr.get(i).length-1) System.out.print(" , ");
            }
            System.out.print("]");
            System.out.println();
        }
    }
    public static int[][] generateArray(){
        int [][] arr  = new int[row][col];
        for (int i = 0; i <row ; i++) {
                arr[i][0]=getRandomNumber();
        }
        for (int i = 0; i < row; i++) {
            for (int j = 1; j < col; j++) {
                arr[i][j]=arr[i][0];
            }
        }
        return arr;
    }
    public static int getRandomNumber(){
     return  (int)Math.floor(Math.random()*(20-10+1)+10);
    }//t
}
