﻿using System;
using static System.Console;
namespace Lab8
{
    public class Program
    {
         int P = 3, Q = 11, N, F_n, K = 7, k = 3, c;
        List<int>C= new List<int>();
        char[] alphabets = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z' };
        public Program()
        {
            N = P * Q;
            F_n = (P-1)*(Q-1);
          //  WriteLine("== " + (K * k)%F_n);
        }
        public bool isOne()
        {
            return (K * k) % F_n == 1;
        }
        public  void encrypt(string word)
        {
            
            char[] new_alph= word.ToCharArray();
           for (int i = 0; i < new_alph.Length; i++)
            {
                for (int j = 0; j < alphabets.Length; j++)
              
                    if(new_alph[i] == alphabets[j])
                    {
                        c = Convert.ToInt32(Math.Pow(j,K) % N);
                        C.Add(c);
                        break;
                    }
            }
         //   WriteLine("\t\t*********************");
            Write("\tКриптограмма С = ");
           foreach(int i in C)
            {
                Write(i+" ");
            }
              WriteLine("\n********************************************");
         //   WriteLine("===================================");
            C = new List<int>();
        }
        public  void decrypt(string number)
        {
            int testNumber;
            var numbers = number.Split(' ');
            string message="";
            for(int i = 0; i < numbers.Length; i++)
            {
                testNumber = Convert.ToInt32(Math.Pow(Convert.ToInt32(numbers[i]), k) % N);
                message += alphabets[testNumber];     
            }
            WriteLine("\t\t*******************");
            WriteLine("\t\t*The Message is "+message+"*");
            WriteLine("\t\t*******************");
            WriteLine("==================================================");
            message = "";
        }
        public static void Main(string[] args)
        {        
            Program program = new Program();
            string word, number;
            int n = 0;
            WriteLine("1.Зашифровать.\n2.Расшифровать.\n3.Закрыть");
            n = Convert.ToInt32(ReadLine());
            while (n != 3)
            {
                
                switch (n)
                {
                    case 1:
                        Write("Input => ");
                        word=ReadLine();
                       program.encrypt(word);
                        break;
                        case 2:
                        Write("Криптограмма С = ");
                        number=ReadLine();
                        program.decrypt(number);
                        break;                      
                }
                WriteLine("1.Зашифровать.\n2.Расшифровать.\n3.Закрыть");
                n= Convert.ToInt32(ReadLine());
            }
            //WriteLine("Hi");
        }
    }
}