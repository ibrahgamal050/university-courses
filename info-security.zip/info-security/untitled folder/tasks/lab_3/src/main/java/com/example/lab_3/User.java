package com.example.lab_3;

public class User {

    private String name;
    private double dwellTime;

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", dwellTime=" + dwellTime +
                ", flightTime=" + flightTime +
                '}';
    }

    private double flightTime;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getDwellTime() {
        return dwellTime;
    }

    public void setDwellTime(double dwellTime) {
        this.dwellTime = dwellTime;
    }

    public double getFlightTime() {
        return flightTime;
    }

    public void setFlightTime(double flightTime) {
        this.flightTime = flightTime;
    }

    public User(String name, double dwellTime, double flightTime) {
        this.name = name;
        this.dwellTime = dwellTime;
        this.flightTime = flightTime;
    }
}
