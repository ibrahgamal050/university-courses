package com.example.lab_4;


public class Object {
    private int id ;
    private String operation;

    @Override
    public String toString() {
        return "Object{" +
                "id=" + id +
                ", operation='" + operation + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String operation) {
        this.operation = operation;
    }

    public Object(int id, String operation) {
        this.id = id;
        this.operation = operation;
    }
}
