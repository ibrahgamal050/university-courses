import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.Comparator;

public class Main {



    /*Коммивояжёра
     заключающаяся в поиске самого выгодного маршрута,
     проходящего через указанные города хотя бы по одному
     разу с последующим возвратом в исходный город.
   */
    public static int MyRandom(int min, int max) throws Exception {
        if(min == max){
            return min;
        }
        if(min > max){
            throw new Exception("не правильные параметры");
        }
        return (int)Math.round(Math.random()*(max-min))+min;
    }

    public static void MyShowArr(Integer[] arr){
        System.out.print("[ ");

        for(var elem: arr){
            System.out.print(elem+ " ");
        }
        System.out.print("]\n");
    }

    public static void MyShowArr(int[] arr){
        System.out.print("[ ");

        for(var elem: arr){
            System.out.print(elem+ " ");
        }
        System.out.print("]\n");
    }

//    public static int[] RandomArr(int length, int min, int max) throws Exception {
//        int[] arr = new int[length];
//
//        for(int i = 0; i < length; i++){
//            arr[i] = Lab.MyRandom(min, max);
//        }
//
//        return arr;
//    }

    public static void main(String[] args) throws Exception {
        int n = 10;
        int t1 = 10;
        int t2 = 30;
        int z = 10;
        int k = 10;
        int start = 3;
        double probabilityCrosover = 0.9;
        double probabilityMuration = 1;

        Integer[][] matrix = new Integer[n][];
        for(int i = 0; i < n; i++){
            matrix[i] = new Integer[n];
            for(int j = 0; j< i+1; j++){
                if(i!=j){
                    matrix[i][j] = Main.MyRandom(t1,t2);
                    matrix[j][i] = matrix[i][j];
                }else{
                    matrix[i][j] = null;
                }
            }
        }

        GenetikAlg galg = new GenetikAlg(n, matrix, z, k, start, probabilityCrosover, probabilityMuration);
        Individual genRes = galg.start();
        Zhadni zalg = new Zhadni(n, matrix);
        Individual zhadRes = zalg.getShortWay();
        System.out.println("Результат генетического = " + genRes);
        System.out.println("Результат жадного = " + zhadRes);


        //--Визуализация
        JFrame frame = new JFrame("Lab7");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500,500);
        MyPanel mp = new MyPanel(n, matrix);
        mp.addWay(genRes,Color.red);
        mp.addWay(zhadRes,Color.blue);
        frame.add(mp);
        frame.setVisible(true);
    }
}






class GenetikAlg{
    private Integer[][] matrix;
    private Generation generation;
    private int lastBest;
    private int n;
    private int z;
    private int k;
    private int start;
    private int numbGen = 1;
    private int k_ = 0;
    private double probabilityCrosover;
    private double probabilityMuration;



    public GenetikAlg(int n, Integer[][] matrix, int z, int k, int start, double probabilityCrosover, double probabilityMuration) throws Exception {
        this.n = n;
        this.z = z;
        this.k = k;
        this.start = start;
        this.probabilityCrosover = probabilityCrosover;
        this.probabilityMuration = probabilityMuration;

        this.matrix = matrix;
        generation = new Generation(matrix, z,start);
    }

    public Individual start() throws Exception {
        System.out.println("Мтрица");
        for (var lain: matrix){
            Main.MyShowArr(lain);
        }
        System.out.println();

        while(k_ < k){
            choosePair();
            int bestNow = generation.getbest();
            if(bestNow == lastBest){
                k_++;
            }else{
                k_ = 0;
                lastBest = bestNow;
            }
            numbGen++;
//            System.out.println(generation);
            generation.createNextGeneration();
        }
        System.out.println();
        System.out.println("лучшее поколение " + numbGen);
        System.out.println(generation);
        return generation.getbestIndividual();
    }



    public void choosePair() throws Exception {
        System.out.println();
        System.out.println("Поколение "+ numbGen);
        System.out.println("Родители");
        System.out.println(generation);
        int z_ = z;

        for(int i = 0; i < z; i++){
            for(int j = i+1; j < z; j++){
                double left = (z-j+(z-i-1)*(z-i-2)*1.0/2);

                if(z_ > 0 && Math.random() < (z_)/left){
                    System.out.println();
                    System.out.println("Пара " + i + " " + j);
                    comparator(i,j);
                    z_--;
                }
            }
        }
    }

    public void mutator(int[] arr) throws Exception {
        int swichI1 = Main.MyRandom(1,n-1);
        int swichI2 = Main.MyRandom(1,n-1);

        if(swichI2 == swichI1){
            swichI2 = (swichI2)%(n-1)+1;
        }

        System.out.println("Заменяемые вершины "+ arr[swichI1] + " и " + arr[swichI2]);

        int temp = arr[swichI1];
        arr[swichI1] = arr[swichI2];
        arr[swichI2] = temp;
    }

    public void comparator(int parentId1, int parentId2) throws Exception {
        if(parentId1 == parentId2 || parentId1 >= z || parentId2 >= z){
            throw new Exception("не правильные параметры");
        }
        int[] parent1 = generation.get(parentId1).getWay();
        int[] parent2 = generation.get(parentId2).getWay();
        Main.MyShowArr(parent1);
        Main.MyShowArr(parent2);
        int border;
        if(n-2 <2){
            border = 2;
        }else{
            border = Main.MyRandom(2, n-2);
        }
        int[] child1 = new int[n+1];
        int[] child2 = new int[n+1];
        int currentLength1 = border;
        int currentLength2 = border;

        System.out.println("Барьер " + border);
        for(int i = 0; i < border ; i++){
            child1[i] = parent1[i];
            child2[i] = parent2[i];
        }

        ////---------Вот-тут-По-Другому

        for(int i = 1; i < n ; i++){
            if(currentLength1 < n){
                boolean isContainI = false;
                for(int j = 1; j < currentLength1;j++){
                    if(child1[j] == parent2[i]){
                        isContainI = true;
                        break;
                    }
                }
                if(!isContainI){
                    child1[currentLength1] = parent2[i];
                    currentLength1++;
                }
            }
            if(currentLength2 < n){
                boolean isContainI = false;
                for(int j = 1; j < currentLength2;j++){
                    if(child2[j] == parent1[i]){
                        isContainI = true;
                        break;
                    }
                }
                if(!isContainI){
                    child2[currentLength2] = parent1[i];
                    currentLength2++;
                }
            }
        }
        child1[n] = start;
        child2[n] = start;
        System.out.println("Дети");
        Main.MyShowArr(child1);
        Main.MyShowArr(child2);
        System.out.println(new Individual(matrix, child1).getFunctionValue() + " Значение целевой ф-ии рекбенка" + parentId1 + "" + parentId2 + " до возможной мутации");
        System.out.println(new Individual(matrix, child2).getFunctionValue() + " Значение целевой ф-ии рекбенка" + parentId2 + "" + parentId1 + " до возможной мутации");
        if(Math.random() < probabilityMuration){
            mutator(child1);
            System.out.println("Ребенок" + parentId1 + "" + parentId2 +" после мутации");
            Main.MyShowArr(child1);
        }
        if(Math.random() < probabilityMuration){
            mutator(child2);
            System.out.println("Ребенок" + parentId2 + "" + parentId1 +" после мутации");
            Main.MyShowArr(child2);
        }
        Individual iСhild1 = new Individual(matrix, child1);
        Individual iСhild2 = new Individual(matrix, child2);
        System.out.println("Загруженность");
        System.out.println(generation.get(parentId1).getFunctionValue() + " Значение целевой ф-ии родителя" + parentId1);
        System.out.println(generation.get(parentId2).getFunctionValue() + " Значение целевой ф-ии родителя" + parentId2);
        System.out.println(iСhild1.getFunctionValue() + " Значение целевой ф-ии рекбенка" + parentId1 + "" + parentId2);
        System.out.println(iСhild2.getFunctionValue() + " Значение целевой ф-ии рекбенка" + parentId2 + "" + parentId1);
        generation.add(iСhild1);
        generation.add(iСhild2);
    }

}

class Generation{
    private ArrayList<Individual> individuals = new ArrayList<>();
    private int z;

    public static int[]RandomCycle(int n, int start) throws Exception {
        int[] arr = new int[n+1];
        ArrayList<Integer> numbers = new ArrayList<>();
        for(int i = 0; i < n; i++){
            if(i != start){
                numbers.add(i);
            }
        }
        arr[0] =start;
        arr[n] = start;
        for(int i = 0; i < arr.length-2; i++){
            arr[i+1] = numbers.remove(Main.MyRandom(0,numbers.size()-1));
        }

        return arr;
    }

    public Generation(Integer[][] matrix, int z, int start) throws Exception {
        this.z = z;

        for(int i = 0; i < z; i++){
            individuals.add(new Individual(matrix, RandomCycle(matrix.length, start)));
        }
    }

    public Individual get(int i) throws Exception {
        if(i<0 || i >= individuals.size()){
            throw new Exception("Вышли за границы массива особей");
        }

        return individuals.get(i);
    }

    public void add(Individual individual){
        individuals.add(individual);
    }

    public void createNextGeneration(){
        individuals.sort(new Comparator<Individual>() {
            @Override
            public int compare(Individual o1, Individual o2) {
                if(o1.getFunctionValue() > o2.getFunctionValue()){
                    return -1;
                } else if(o1.getFunctionValue() == o2.getFunctionValue()){
                    return 0;
                } else {
                    return 1;
                }
            }
        });

        while(individuals.size() > z){
            individuals.remove(0);
        }
    }

    public int getbest(){
        return getbestIndividual().getFunctionValue();
    }

    public Individual getbestIndividual(){
        int minI = 0;
        int size = individuals.size();

        for(int i = 1; i < size; i++){
            if(individuals.get(i).getFunctionValue() < individuals.get(minI).getFunctionValue()){
                minI = i;
            }
        }

        return individuals.get(minI);
    }

    @Override
    public String toString() {
        String out = "[\n";

        for(var individ: individuals ){
            out += "\t" + individ.toString() +"\n";
        }
        out += "]";

        return out;
    }
}

class Individual{
    private int[] way;
    private int functionValue;

    public Individual(Integer[][] matrix, int[] way){
        this.way = new int[way.length];
        functionValue = 0;

        for(int i = 0; i < way.length; i++){
            this.way[i] = way[i];
        }

        for(int i = 0; i < way.length-1; i++){
            functionValue+=matrix[way[i]][way[i+1]];

        }

    }

    public int[] getWay(){
        int[] sendedArr = new int[way.length];

        for(int i = 0; i < way.length; i++){
            sendedArr[i] = way[i];
        }

        return sendedArr;
    }

    public int getFunctionValue(){

        return functionValue;
    }

    @Override
    public String toString() {
        String out = "[ ";

        for(var elem: way){
            out += elem+ " ";
        }
        out += "] Значение целевой функции = " + getFunctionValue();

        return out;
    }

}