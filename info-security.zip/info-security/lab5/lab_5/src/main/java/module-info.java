module com.example {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.apache.commons.lang3;


    opens com.example.lab_5 to javafx.fxml;
    exports com.example.lab_5;
}