import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class RSA {
    public static int p = 3; //17
    public static int q = 11; //41
    public static int kb = 3,Kb = 7;
    public static int publicKey = generatePublicKey(p,q);
    public static int privateKey = generatePrivateKey(p,q);
    public static int eiler = generatePrivateKey(p,q);
    public static int N = generatePublicKey(p,q);
    public static char alphabets[] = new char[] {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T',
            'U','V','W','X','Y','Z'};
    public static String message,decryptedMessage;
    public static int[] encryptedMessage;
    public static int generatePublicKey(int p,int q){
        return p*q;
    }
    public static int generatePrivateKey(int p,int q){
        return (p-1)*(q-1);
    }
    public static boolean isOne(){
        boolean flag = true;
        for (int i = 0; i < 1000; i++) {
            //Kb = i;
            if((Kb*kb)%eiler == 1){
                flag = true;
            }
            else flag = false;
        }
        return flag;
    }
    public static int[] encryptMessage(String message,int N,int Kb) {
        int encryptedNumber[] = new int[message.length()];
        for (int i=0;i<message.length();i++){
            for (int j = 0; j < alphabets.length; j++) {
                if(message.charAt(i) == alphabets[j]){
                    encryptedNumber[i] = (int) (Math.pow(j+1,Kb)%N);
                }
            }
        }
        return encryptedNumber;
    }
    public static String decryptMessage(int[] encryptedNumber,char[] alphabets,int N,int kb){
        String Newstr = " ";
        int o;
        for (int i = 0; i < encryptedNumber.length; i++) {
            o = (int) (Math.pow(encryptedNumber[i],kb)%N);
            Newstr+=alphabets[o-1];
        }
        return Newstr;
    }
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int choice;
        System.out.println("Public key = " + publicKey);
        System.out.println("Private key = " + privateKey);
        System.out.println("1.Encrypt message");
        System.out.println("2.Decrypt message");
        System.out.println("3.Exit");
        do {
            System.out.println("Enter your choice : ");
            choice = sc.nextInt();
            switch (choice){
                case 1 :
                    if(isOne()) {
                        System.out.println("Enter message to be encrypted : ");
                        sc.nextLine();
                        message = sc.nextLine();
                        System.out.println("Message entered : " + message);
                        encryptedMessage = encryptMessage(message, N, Kb);
                        System.out.println("Encrypted message " + Arrays.toString(encryptedMessage));
                    }
                    else {
                        System.out.println("кв not coprime with the Euler function");
                    }
                    break;
                case 2 :
                    if(encryptedMessage==null){
                        System.out.println("Please encrypt a message first");
                    }
                    else {
                        decryptedMessage = decryptMessage(encryptedMessage,alphabets,N,kb);
                        System.out.println("Decrypted message " + decryptedMessage);
                    }
                    break;
                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Wrong choice!!");
                    break;
            }

        } while (choice!=3);
    }
}