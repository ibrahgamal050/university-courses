
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;

    public class MyPanel extends JPanel {
        private Circul[] circuls;
        private ArrayList<Individual> ways = new ArrayList<>();
        private ArrayList<Color> colors = new ArrayList<>();
        private boolean isPress = false;
        private Integer movedCirculId = null;
        private Integer[][] matrix;


        @Override
        public void paint(Graphics g){
            Graphics2D g2 =(Graphics2D) g;
            g2.setStroke(new BasicStroke(1));
            g2.clearRect(0,0 ,getWidth(),getHeight());
            g2.setColor(Color.black);
            for(int i = 0; i < circuls.length; i++){
                for(int j = i+1; j<circuls.length; j++){
                    g2.drawLine(circuls[i].x, circuls[i].y, circuls[j].x,circuls[j].y);
                }
            }
            for(int i = 0; i < ways.size(); i++){
                g2.setColor(colors.get(i));
                g2.setStroke(new BasicStroke((ways.size()+1-i)*2));
                int[] way = ways.get(i).getWay();
                int lastPoint = way[0];
                for(int j =1; j<way.length; j++){
                    g2.drawLine(circuls[lastPoint].x, circuls[lastPoint].y, circuls[way[j]].x,circuls[way[j]].y);
                    lastPoint = way[j];
                }
            }
            g2.setStroke(new BasicStroke(1));
            g2.setColor(Color.black);
            for(var circul_: circuls){
                g2.fillOval(circul_.x-circul_.width/2,circul_.y-circul_.width/2,circul_.width,circul_.width);
            }
            g2.setColor(Color.white);
            for(var circul_: circuls) {
                g2.drawString(circul_.text, circul_.x, circul_.y);
            }
            g2.setColor(Color.black);
            for(int i = 0; i < matrix.length; i++){
                for(int j = i+1; j < matrix[i].length; j++){
                    int x = (circuls[i].x + circuls[j].x)/2;
                    int y = (circuls[i].y + circuls[j].y)/2;
                    g2.drawString(matrix[i][j] + "", x, y);
                }
            }
        }

        public void addWay(Individual way, Color clr){
            ways.add(way);
            colors.add(clr);
            repaint();
        }

        public MyPanel(int n, Integer[][] matrix){
            super();
            this.matrix = matrix;
            circuls = new Circul[n];
            for(int i = 0; i < circuls.length; i++){
                circuls[i] = new Circul(i*70+30,i*70+30,(i) + "");
            }
            this.addMouseListener(new MouseListener() {
                @Override//w  w w.j  a  v  a  2 s.c om
                public void mouseClicked(MouseEvent e) {
//                System.out.println("1");
                }

                @Override
                public void mousePressed(MouseEvent e) {
//                System.out.println("2"); //start
                    isPress = true;
                    for(int i = 0; i < circuls.length; i++){
                        if(Math.sqrt(Math.pow((e.getX() - circuls[i].x),2) + Math.pow((e.getY() - circuls[i].y),2))  <= circuls[i].width/2 ){
                            movedCirculId = i;
//                        System.out.println(i);
                            break;
                        }
                    }
                }

                @Override
                public void mouseReleased(MouseEvent e) {
//                System.out.println("3"); //end
                    movedCirculId = null;
                    isPress = false;
                }

                @Override
                public void mouseEntered(MouseEvent e) {
//                System.out.println("4");
                }

                @Override
                public void mouseExited(MouseEvent e) {
//                System.out.println("5");
                }
            });
            this.addMouseMotionListener(new MouseMotionListener() {
                @Override
                public void mouseDragged(MouseEvent e) {
//                System.out.println("q");
//                if(isPress){
                    if(movedCirculId != null){
                        circuls[movedCirculId].x = e.getX();
                        circuls[movedCirculId].y = e.getY();
//                        System.out.println(e.getX() + " " + e.getY());
//                    System.out.println("mowe");
                        repaint();
                    }
//                }
                }

                @Override
                public void mouseMoved(MouseEvent e) {

                }
            });
        }
    }

    class Circul{
        public int x;
        public int y;
        public int width = 50;
        public String text;

        public Circul(int x, int y, String text){
            this.x = x;
            this.y = y;
            this.text = text;
        }
    }

