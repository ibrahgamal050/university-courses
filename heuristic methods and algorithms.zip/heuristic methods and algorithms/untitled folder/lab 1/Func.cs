namespace Laba1
{

    public class Func
    {
        public List<List<int>> list = new List<List<int>>();
        public List<List<int>> CMP_Temp(List<int> works, int procCount)
        {
            List<List<int>> procs = new List<List<int>>();
            for (int i = 0; i < procCount; i++) { procs.Add(new List<int>()); }
            int min = int.MaxValue;
            int summ;
            while (works.Count != 0)
            {
                int minInd = 0;
                for (int i = 0; i < procCount; ++i)
                {
                    summ = 0;
                    foreach (int el in procs[i]) { summ += el; }
                    if (summ == 0) { minInd = i; break; }
                    if (summ < min) { min = summ; minInd = i; }

                }
                procs[minInd].Add(works[0]);
                int summ1 = 0;
                foreach (var el in procs[minInd]) { summ1 += el; }
                min = int.MaxValue;
                works.RemoveAt(0);
            }
            return procs;
        }
        public void OFMT_Rec(List<int> works, int counter)
        {
            var c = counter;
            if (c > 1)
            {
                var r = CMP_Temp(works, 2);
                c--;
                OFMT_Rec(r[0], c);//левая часть
                OFMT_Rec(r[1], c);// правая часть
            }
            if (c == 1)
            {
                var r = CMP_Temp(works, 2);
                list.AddRange(r);
            }
        }

        public List<List<int>> CMP(int n, int m, int a, int b)
        {
            int[][] matrix = new int[m][];
            Console.WriteLine("Матрица: ");
            for (int i = 0; i < m; i++)
            {
                matrix[i] = new int[n];
                var rnd = new Random();
                int randNum = rnd.Next(a, b);
                for (int j = 0; j < n; j++)
                {
                    matrix[i][j] = randNum;
                    Console.Write($"{matrix[i][j]} ");
                }
                Console.WriteLine();
            }
            List<int> works = new List<int>();
            for (int i = 0; i < m; i++) { works.Add(matrix[i][0]); }
            works.Sort();
            works.Reverse();
            Console.WriteLine("Задания: ");
            for (int i = 0; i < works.Count; i++)
            {
                Console.Write($"{works[i]} ");
            }
            Console.WriteLine();

            //CMP

            var procs = CMP_Temp(works, n);
            int iteraror = 1;
            foreach (var proc in procs)
            {
                int summ = 0;
                Console.WriteLine($"№{iteraror}");
                foreach (var elem in proc)
                {
                    Console.Write($"{elem} ");
                    summ += elem;
                }
                Console.Write($"\t=: {summ}");
                Console.WriteLine();
                iteraror++;
            }

            return procs;
        }
        public List<List<int>> HDMT(int n, int m, int a, int b)
        {
            if (n % 2 != 0) { Console.Write("Нечетное число процессов!\n"); return null; }
            int[][] matrix = new int[m][];
            Console.WriteLine("Матрица: ");
            for (int i = 0; i < m; i++)
            {
                matrix[i] = new int[n];
                var rnd = new Random();
                int randNum = rnd.Next(a, b);
                for (int j = 0; j < n; j++)
                {
                    matrix[i][j] = randNum;
                    Console.Write($"{matrix[i][j]} ");
                }
                Console.WriteLine();
            }
            List<int> works = new List<int>();
            for (int i = 0; i < m; i++) { works.Add(matrix[i][0]); }
            works.Sort();
            works.Reverse();
            works = new List<int>() { 15, 15, 14, 14, 14, 13, 13, 12, 11, 10, 10, 10, 10, 9, 9 };
            Console.WriteLine("Задания: ");
            for (int i = 0; i < works.Count; i++)
            {
                Console.Write($"{works[i]} ");
            }
            Console.WriteLine();
            //HDMT
            Console.WriteLine("Решение: ");
            //First level
            Console.WriteLine("1 уровень: ");
            var firstLevelProc = CMP_Temp(works, 2);
            int iteraror = 1;
            foreach (var proc in firstLevelProc)
            {
                Console.WriteLine($"№{iteraror}");
                foreach (var elem in proc)
                {
                    Console.Write($"{elem} ");
                }
                Console.WriteLine();
                iteraror++;
            }
            //Second level

            Console.WriteLine("2 уровень: ");
            var secondLevelProc1 = CMP_Temp(firstLevelProc[0], n / 2);
            var secondLevelProc2 = CMP_Temp(firstLevelProc[1], n / 2);
            iteraror = 1;
            foreach (var proc in secondLevelProc1)
            {
                Console.WriteLine($"№{iteraror}");
                foreach (var elem in proc)
                {
                    Console.Write($"{elem} ");
                }
                Console.WriteLine();
                iteraror++;
            }
            foreach (var proc in secondLevelProc2)
            {
                Console.WriteLine($"№{iteraror}");
                foreach (var elem in proc)
                {
                    Console.Write($"{elem} ");
                }
                Console.WriteLine();
                iteraror++;
            }
            List<List<int>> result = new List<List<int>>();
            result.AddRange(secondLevelProc1);
            result.AddRange(secondLevelProc2);
            iteraror = 1;

            Console.WriteLine("Решение: ");
            foreach (var res in result)
            {
                int summ = 0;
                Console.WriteLine($"№{iteraror}");
                foreach (var elem in res)
                {
                    Console.Write($"{elem} ");
                    summ += elem;
                }
                Console.Write($"\t=: {summ}");
                Console.WriteLine();
                iteraror++;
            }
            return result;
        }
        public void OFMT(int n, int m, int a, int b)
        {
            if (!(n > 0 && (n & (n - 1)) == 0)) { Console.WriteLine("Число процессоров не является 2^x"); return; }
            int levelsCount = Convert.ToInt32(Math.Sqrt(Convert.ToDouble(n)));

            //матрица
            int[][] matrix = new int[m][];
            Console.WriteLine("Матрица: ");
            for (int i = 0; i < m; i++)
            {
                matrix[i] = new int[n];
                var rnd = new Random();
                int randNum = rnd.Next(a, b);
                for (int j = 0; j < n; j++)
                {
                    matrix[i][j] = randNum;
                    Console.Write($"{matrix[i][j]} ");
                }
                Console.WriteLine();
            }

            //задачи
            List<int> works = new List<int>();
            for (int i = 0; i < m; i++) { works.Add(matrix[i][0]); }
            works.Sort();
            works.Reverse();
            Console.WriteLine("Задание: ");
            for (int i = 0; i < works.Count; i++)
            {
                Console.Write($"{works[i]} ");
            }
            Console.WriteLine();


            OFMT_Rec(works, levelsCount);

            Console.WriteLine("Решение: ");
            foreach (var r in list)
            {
                int summ = 0;
                foreach (var i in r)
                {
                    Console.Write($"{i} ");
                    summ += i;
                }
                if (summ != 0)
                {
                    Console.Write($"\t=: {summ}");
                    Console.WriteLine();
                }
            }
        }
    }
}
