import java.util.*;
import java.util.ArrayList;
import java.util.Random;
public class lab {
    public static void main(String[] args)
     {
        Scanner scanner = new Scanner(System.in);
    
        System.out.print("Введите число столбцов: ");
        int n = scanner.nextInt();
        System.out.print("Ведите число строк: ");
        int m = scanner.nextInt();
        System.out.print("Введите диапозон t1: ");
        int t1 = scanner.nextInt();
        System.out.print("Введите диапозон t2: ");
        int t2 = scanner.nextInt();
    
        List<Integer> p = new ArrayList<>();
        for (int i = 0; i < m; i++) {
            p.add((int) (Math.random() * (t2 - t1 + 1)) + t1);
        }
    
        int[][] mas = new int[m][n];
        for (int i = 0; i < mas.length; i++) {
            mas[i][0] = p.get(i);
        }
        for (int i = 0; i < mas.length; i++) {
            for (int j = 1; j < mas[i].length; j++) {
                mas[i][j] = mas[i][j - 1];
            }
        }
        printMatrix(mas);
    
        System.out.println("\n\nЗадание 1 ");
        kron(raspl1(mas, p));
    
       //System.out.println("\n\nЗадание 2 ");
       // kron(raspl2(mas, p));
    
       // System.out.println("\n\nЗадание 3 ");
        //kron(raspl3(mas, p));
       }
    
    public static void printMatrix(int[][] mas) {
        System.out.println();
        for (int[] row : mas) {
            for (int i2 : row) {
                System.out.print(i2 + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
    
    public static List<List<Integer>> raspl1(int[][] mas, List<Integer> p) {
        List<List<Integer>> matrix = new ArrayList<>();
        for (int i = 0; i < mas[0].length; i++) {
            matrix.add(new ArrayList<>());
        }
        for (int j = 0; j < mas.length; j++) {
            int rand = (int) (Math.random() * mas[0].length);
            matrix.get(rand).add(p.get(j));
        }
        printMatrix(matrix);
        return matrix;
    }
    
    public static List<List<Integer>> raspl2(int[][] mas, List<Integer> p) {
        List<List<Integer>> matrix = new ArrayList<>();
        for (int i = 0; i < mas[0].length; i++) {
            matrix.add(new ArrayList<>());
            matrix.get(i).add(0);
        }
        for (int i = 0; i < p.size(); i++) {
            List<Integer> summ = new ArrayList<>();
            for (int j = 0; j < matrix.size(); j++) {
                int sum = matrix.get(j).stream().mapToInt(Integer::intValue).sum();
                summ.add(sum);
            }
            int indexMin = summ.indexOf(Collections.min(summ));
            matrix.get(indexMin).add(p.get(i));
        }
        for (int i = 0; i < matrix.size(); i++) {
            matrix.get(i).removeIf(j -> j == 0);
        }
        printMatrix(matrix);
        return matrix;
           }
        public static int[][] raspl3(int[][] mas, int[] p) {
            int[][] matrix = new int[mas[0].length][];
            for (int i = 0; i < matrix.length; i++) {
                matrix[i] = new int[0];
            }
            int[] p1 = Arrays.copyOf(p, p.length);
            int i = 0;
            for (int j = 0; j < p.length; j++) {
                int maxx = Integer.MIN_VALUE;
                int index = -1;
                for (int k = 0; k < p1.length; k++) {
                    if (p1[k] > maxx) {
                        maxx = p1[k];
                        index = k;
                    }
                }
                matrix[i] = Arrays.copyOf(matrix[i], matrix[i].length + 1);
                matrix[i][matrix[i].length - 1] = maxx;
                p1[index] = Integer.MIN_VALUE;
                i++;
                if (i == matrix.length) {
                    i = 0;
                }
            }
            printMatrix(matrix);
            return matrix;
        }


   public static void kron(int[][] matrix) {
    int[] summ = new int[matrix.length];
     for (int i = 0; i < matrix.length; i++) {
    summ[i] = Arrays.stream(matrix[i]).sum();
      }
    System.out.println(Arrays.toString(summ));
   int index_max = IntStream.range(0, summ.length).reduce((a, b) -> summ[a] > summ[b] ? a : b).getAsInt();
   int index_min = IntStream.range(0, summ.length).reduce((a, b) -> summ[a] < summ[b] ? a : b).getAsInt();
   System.out.println(index_max + " " + index_min);
      int delta = Arrays.stream(summ).max().getAsInt() - Arrays.stream(summ).min().getAsInt();
    System.out.println(delta);
    for (int i : matrix[index_max]) {
     if (i < delta) {
List<Integer> listMin = Arrays.stream(matrix[index_min]).boxed().collect(Collectors.toList());
listMin.add(i);
matrix[index_min] = listMin.stream().mapToInt(Integer::intValue).toArray();
List<Integer> listMax = Arrays.stream(matrix[index_max]).boxed().collect(Collectors.toList());
listMax.remove((Integer) i);
matrix[index_max] = listMax.stream().mapToInt(Integer::intValue).toArray();
printMatrix(matrix);
kron(matrix);
return;
}
}
System.out.println("------------------------------------------");
for (int i : matrix[index_max]) {
for (int j : matrix[index_min]) {
if (i > j && i - j < delta) {
List<Integer> listMin = Arrays.stream(matrix[index_min]).boxed().collect(Collectors.toList());
listMin.add(i);
listMin.remove((Integer) j);
matrix[index_min] = listMin.stream().mapToInt(Integer::intValue).toArray();
List<Integer> listMax = Arrays.stream(matrix[index_max]).boxed().collect(Collectors.toList());
listMax.remove((Integer) i);
listMax.add(j);
matrix[index_max] = listMax.stream().mapToInt(Integer::intValue).toArray();
kron(matrix);
return;
}
}
}
printMatrix(matrix);
System.out.println("Суммы = " + Arrays.toString(summ));
System.out.println("Дельта = " + delta);
  }
 
        
    
}

