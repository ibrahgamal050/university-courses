package com.example.lab_5;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.Rectangle2D;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.*;
import javafx.stage.Screen;
import javafx.stage.Stage;
import org.apache.commons.lang3.time.StopWatch;
import java.io.*;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class HelloApplication extends Application {
   public static Button button;
   public static BorderPane root;
   public static TextField editText;
   public static VBox vBox;
   public static Label text;
   public static boolean login =false;
   public static ArrayList<User>usersList;
   public static double dwellTime = 0;
   public static double flightTime =0;
   public static User currentUser ;
    @Override
    public void start(Stage stage) throws IOException {
        setInterface(stage);
        File file = new File("users.txt");
        FileInputStream inputStream = new FileInputStream(file);
        usersList = readUsersInputStream(inputStream);

        buttonListener();
    }
    public static ArrayList readUsersInputStream(InputStream inputStream) throws IOException {
        ArrayList<User> list =new ArrayList();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            String name;

            while ((line = br.readLine()) != null) {
                String dwellTime_S = "";
                String flightTime_S ="";
                name =line;
                name = name.replaceFirst(",.*", "");
                int i =0;
                while (line.charAt(i)!=','){
                    i++;
                }
                i++;
                while (line.charAt(i)!=','){
                    dwellTime_S+=line.charAt(i);
                    i++;
                }
                i++;
                while (line.charAt(i)!='.'){
                    flightTime_S+=line.charAt(i);
                    i++;
                }
                double dwellTime = Double.parseDouble(dwellTime_S);
                double flightTime = Double.parseDouble(flightTime_S);
                list.add(new User(name,dwellTime,flightTime));
            }
        }
        return list;
    }
    public static ArrayList readTextInputStream(InputStream inputStream) throws IOException {
        ArrayList<String> list =new ArrayList();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(inputStream))) {
            String line;
            while ((line = br.readLine()) != null) {
                list.add(line);
            }
        }
        return list;
    }
    public static void print(ArrayList<User> list){
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }
    public static boolean userExist(String user){
        for (int i = 0; i < usersList.size(); i++) {
            if(user.equals(usersList.get(i).getName())){
                currentUser =new User (usersList.get(i).getName(),usersList.get(i).getDwellTime(),usersList.get(i).getFlightTime());
                return true;
            }
        }
        return false;
    }
    public static boolean authenticated(){
        System.out.println(dwellTime);
        System.out.println(flightTime);
        if(editText.getText().equals(text.getText())){
            if (currentUser.getFlightTime()>= flightTime && currentUser.getDwellTime()>=dwellTime){
                return true;
            }
        }
        return false;
    }
    public static void getRandomText(){
        try {
            File file = new File("text.txt");
            FileInputStream inputStream = new FileInputStream(file);
            ArrayList<String> list = readTextInputStream(inputStream);
            text.setText(list.get(getRandomNumber(list.size()-1)));
            text.setVisible(true);
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public static void setInterface(Stage stage){
        stage.setResizable(false);
        root = new BorderPane();
        editText = new TextField();
        button = new Button("login");
        vBox = new VBox(10);
        BorderPane.setMargin(vBox, new Insets(12,20,12,20)); // optional
        text = new Label();
        vBox.setAlignment(Pos.CENTER);
        text.setVisible(false);
        vBox.getChildren().addAll(editText,text,button);
        root.setCenter(vBox);
        Scene scene = new Scene(root, 300, 250);
        stage.setTitle("Test!");
        stage.setScene(scene);
        stage.show();
        Rectangle2D primScreenBounds = Screen.getPrimary().getVisualBounds();
        stage.setX((primScreenBounds.getWidth() - stage.getWidth()) / 2);
        stage.setY((primScreenBounds.getHeight() - stage.getHeight()) / 2);
    }
    public static void buttonListener(){
        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                if(!login){
                    String user =editText.getText();
                    if(userExist(user)){
                        login = true;
                        editText.setText("");
                        button.setText("authenticate");
                        getRandomText();
                        textStopWatch();
                        

                    }else{
                        text.setVisible(true);
                        text.setText("user not exist !!!");
                        editText.setText("");
                        button.setText("login");
                    }
                }else if (login){

                    if(authenticated()){
                        editText.setVisible(false);
                        text.setText("authentication successful");
                        button.setVisible(false);
                    }else {
                        editText.setVisible(false);
                        text.setText("authentication failed");
                        button.setVisible(false);
                    }
                }
            }
        });
    }
    public static void textStopWatch(){
        StopWatch stopWatch = new StopWatch();
        editText.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                stopWatch.reset();
                stopWatch.start();
            }
        });
        editText.setOnKeyReleased(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent keyEvent) {
                if(stopWatch.isStarted()){
                    stopWatch.stop();
                    dwellTime += stopWatch.getTime(TimeUnit.MILLISECONDS)/text.getText().length();
                    flightTime += (int) ((stopWatch.getTime(TimeUnit.MILLISECONDS) - dwellTime) / text.getText().length());
                }
            }
        });
    }
    public static void main(String[] args) {
        launch();
    }
    public static int  getRandomNumber(int max){
        return  (int)Math.floor(Math.random()*(max-0+1)+0);
    }

}