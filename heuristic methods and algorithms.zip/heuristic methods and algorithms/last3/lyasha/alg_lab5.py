from random import randint as rand
from random import sample
#Мутировали
m = 6  # количество заданий //الطول
n = 4  # кол-во процессоров
t1 = 10  # min
t2 = 19  # max
z = 5  # кол-во особей в нач популяции
k = 5  # повтор лучших особей
fraction = 256

pk = 0.93 * 100  # вероятность кроссовера
pm = 0.93 * 100  # вероятность мутации


def create_individual(min_weight, max_weight, max_value, length):
    weights = [rand(min_weight, max_weight) for _ in range(length)]
    values = [rand(0, max_value) for _ in range(length)]

    return weights, values


def main():
    sum_generation = []

    count = 0
    gen_counter = 0

    individuals = []

    coef_list = []
    tmp_coef = (fraction) / n
    tmp_val = tmp_coef

    coef_list.append((0, round(tmp_val)))
    tmp_val *= 2

    for _ in range(1, n):
        coef_list.append((round((tmp_val - tmp_coef) + 1), round(tmp_val)))
        tmp_val += tmp_coef

    for _ in range(z):
        individuals.append(create_individual(t1, t2, fraction - 1, m))

    last_elem = list(coef_list[-1])
    last_elem[1] -= 1
    coef_list[-1] = tuple(last_elem)

    print("Промежутки:")
    print(coef_list)

    individual_matrix = [[] for i in range(z)]

    for i in range(len(individual_matrix)):
        for j in range(len(coef_list)):
            individual_matrix[i].append([])

    while count < k:

        gen_counter += 1
        print()
        print("Поколение:", gen_counter, "-------------------------------------------------")

        for individ_n in range(z):

            print("Для", individ_n + 1, "особи")

            individual_matrix = [[] for i in range(z)]

            for i in range(len(individual_matrix)):
                for j in range(len(coef_list)):
                    individual_matrix[i].append([])

            child_weight_matrix = [[] for i in range(2)]

            for i in range(len(child_weight_matrix)):
                for j in range(len(coef_list)):
                    child_weight_matrix[i].append([])

            for i in range(z):
                for j in range(m):
                    for index, (min_v, max_v) in enumerate(coef_list):
                        if min_v <= individuals[i][1][j] <= max_v:
                            individual_matrix[i][index].append(individuals[0][0][j])

            # print(individual_matrix)
            print("Веса:")
            print(individuals[0][0])

            for index, individ in enumerate(individual_matrix, start=1):
                print()
                print("Особь", index)
                print(individuals[index - 1][1], end='')
                print("Max:", sum(max(individ, key=sum)))

            percent = rand(1, 100)
            crossover_individ = sample(range(1, z + 1), 2)
            while percent >= pk:
                crossover_individ = sample(range(1, z + 1), 2)
                percent = rand(1, 100)

            print()
            print("Кроссовер:", crossover_individ)

            position = rand(1, m - 1)
            child_matrix = []

            print("Барьер:", len(individuals[crossover_individ[0] - 1][1][0:position + 1]))
            print(individuals[crossover_individ[0] - 1][1][0:position + 1])

            child_matrix.append(
                individuals[crossover_individ[0] - 1][1][0:position + 1] + individuals[crossover_individ[1] - 1][1][
                                                                           position + 1:])
            child_matrix.append(
                individuals[crossover_individ[1] - 1][1][0:position + 1] + individuals[crossover_individ[0] - 1][1][
                                                                           position + 1:])

            print(child_matrix)

            child_weight_matrix = [[] for i in range(2)]

            for i in range(len(child_weight_matrix)):
                for j in range(len(coef_list)):
                    child_weight_matrix[i].append([])

            for i in range(2):
                for j in range(m):
                    for index, (min_v, max_v) in enumerate(coef_list):
                        if min_v <= child_matrix[i][j] <= max_v:
                            child_weight_matrix[i][index].append(individuals[0][0][j])

            min_index = 2
            min_max = fraction
            for index, individ in enumerate(child_weight_matrix, start=1):
                print()
                s = sum(max(individ, key=sum))
                if sum(max(individ, key=sum)) < min_max:
                    min_index = index - 1
                    min_max = sum(max(individ, key=sum))
                print("Ребёнок", index)
                print(child_matrix[index - 1], end='')
                print("Max:", sum(max(individ, key=sum)))

            # print(min_index + 1, min_max)
            print()
            print("Выбрали ребенка", min_index + 1, "с результатом", min_max)
            min_child = child_matrix[min_index]
            print(min_child)

            position_v = rand(0, m - 1)
            percent = rand(1, 100)
            while percent >= pm:
                position_v = rand(0, m - 1)
                percent = rand(1, 100)

            mutation = position_v + 1
            print()
            print("Мутировали в гене номер =", mutation)
            # print(position_v)

            bin_value = str(bin(min_child[position_v]))[2:]

            print(min_child[position_v], bin_value)
            position = rand(0, len(bin_value) - 1)

            if bin_value[position] == '1':
                bin_value = bin_value[:position] + '0' + bin_value[position + 1:]
            else:
                bin_value = bin_value[:position] + '1' + bin_value[position + 1:]

            value = int(bin_value, 2)
            print(value, bin_value)

            min_child[position_v] = value

            child_matrix[min_index] = min_child
            min_index = 2
            min_max = fraction

            child_weight_matrix = [[] for i in range(2)]

            for i in range(len(child_weight_matrix)):
                for j in range(len(coef_list)):
                    child_weight_matrix[i].append([])

            for i in range(2):
                for j in range(m):
                    for index, (min_v, max_v) in enumerate(coef_list):
                        if min_v <= child_matrix[i][j] <= max_v:
                            child_weight_matrix[i][index].append(individuals[0][0][j])

            print()
            print("Дети после мутации:")

            for index, individ in enumerate(child_weight_matrix, start=1):
                # print()
                s = sum(max(individ, key=sum))
                if sum(max(individ, key=sum)) < min_max:
                    min_index = index - 1
                    min_max = sum(max(individ, key=sum))
                print("Ребёнок", index)
                print(child_matrix[index - 1], end='')
                print("Max:", sum(max(individ, key=sum)))
                print()

            s1 = sum(max(child_weight_matrix[min_index], key=sum))
            s2 = sum(max(individual_matrix[min_index], key=sum))

            if sum(max(child_weight_matrix[min_index], key=sum)) <= sum(max(individual_matrix[individ_n], key=sum)):
                individuals[individ_n] = individuals[individ_n][0], child_matrix[min_index]

            # print()

        sum_tuple = []
        print("Финальные особи:")
        for index, individ in enumerate(individual_matrix, start=1):
            # print()
            print("Особь", index)
            print(individuals[index - 1][1], end='')
            sum_tuple.append(sum(max(individ, key=sum)))
            print("Max:", sum(max(individ, key=sum)))
            print()

        # print()

        sum_generation.append(min(sum_tuple))
        count += 1

        if count > 1:
            if sum_generation[count - 1] != sum_generation[count - 2]:
                sum_generation = []
                count = 0

    print("Нашли за", gen_counter, "поколений")


if __name__ == "__main__":
    main()
