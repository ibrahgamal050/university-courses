import java.util.ArrayList;
import java.util.Collections;

public class Test {
    public static int row = 11 ; // m
    public static int col = 4 ; //n
    public static int t_min = 10; // t min
    public static int t_max = 20; // t max
    public static int[][] arr;
    public static int[][] tempArr;
    public static int[] rowsSum;

    public static void main(String[] args) {
        generateMatrix();
        getSumRows();
        System.out.println("sum the elements in the rows of the matrix");
        printArray(arr,rowsSum);
        sortArrays();
        System.out.println();
        System.out.println("after sorting the rows in descending order by amounts, the matrix will be : ");
        printArray(arr,rowsSum);
        initializeTempArray();
        mainOperation();
        System.out.println();
        System.out.println("After executing the algorithm, we get the table :");
        printArray(tempArr);
        System.out.println();
        System.out.print("max : ");
        System.out.println( " = "+getMax());

    }
    public static int getMax(){
        int max = tempArr[tempArr.length-1][0] ;
        for (int i = 0; i < col; i++) {
            int num = tempArr[tempArr.length-1][i];
            if(max< num){
                max = num;
            }
        }

        return max ;
    }
    public static ArrayList<Integer> getSumColumn(int [][] temp){
        ArrayList<Integer> sumList =new ArrayList<>();
        for (int i = 0; i < col; i++) {
            int sum =0;
            for (int j = 0; j < row; j++) {
                sum+=temp[j][i];
            }
            sumList.add(sum);
        }
        return sumList ;
    }
    public static void mainOperation(){
        for (int i = 0; i < row; i++) {
            int index_min = getMinNum(i);
            for (int j = 0; j < col; j++) {
                if(j == index_min){
                    if(i==0) tempArr [i][j] = arr[i][index_min];
                    else tempArr [i][index_min] = arr[i][index_min]+ tempArr [i-1][index_min];
                }else{
                    if(i!=0) tempArr [i][j] = tempArr[i][j]+ tempArr [i-1][j];
                }

            }
        }
    }
    public static void printArray(int[][] arr){
        for (int i = 0; i < row; i++) {
            System.out.print("[");
            for (int j = 0; j < col; j++) {
                System.out.print(arr[i][j]);
                if(j != col-1) System.out.print(" , ");
            }
            System.out.print("]");
            System.out.println();
        }
    }
    public static void generateMatrix(){
        arr =new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                arr[i][j] = getRandomNumber();
            }
        }
       // arr = new int[][]{{18,17,21,10},{19,15,19,10},{15,16,20,19},{15,12,11,14},{19,10,13,11},{10,17,15,12},{13,18,12,11},{17,17,15,19}};
       // arr =new int [][]{{12,20,20,17},{12,11,16,14},{17,21,16,17},{12,18,17,18},{12,18,19,21},{21,20,15,18},{13,21,10,12},{10,18,21,13},{16,10,11,14},{21,14,14,11},{12,17,17,19},{11,18,17,13},{18,19,10,19},{15,15,14,17},{16,12,10,11}};
    }
    public static void printArray(int[][] arr,int[] arrRes){
        for (int i = 0; i < row; i++) {
            System.out.print("[");
            for (int j = 0; j < col; j++) {
                System.out.print(arr[i][j]);
                if(j != col-1) System.out.print(" , ");
            }
            System.out.print(" ]");
            System.out.print("   sum = "+arrRes[i]);
            System.out.println();
        }
    }
    public static void getSumRows(){
        rowsSum = new int[row];
        for (int i = 0; i < row; i++) {
            int result =0 ;
            for (int j = 0; j < col; j++) {
                result += arr[i][j];
            }
            rowsSum[i]=result;
        }
    }
    public static int  getRandomNumber(){
        return  (int)Math.floor(Math.random()*(t_max-t_min+1)+t_min);
    }
    public static void printArray(ArrayList<Integer> arr){
        System.out.print("[");
        for (int i = 0; i < arr.size(); i++) {
            System.out.print(arr.get(i));
            if(i < arr.size()-1) System.out.print(" , ");
        }
        System.out.print("]");
    }
    public static int  getMinNum(int rowNum){
        int index =0;
        if(rowNum==0){
            double min = arr[rowNum][0] ;
            for (int i = 1; i < col; i++) {
                if(min>arr[rowNum][i]){
                    min = arr[rowNum][i];
                    index=i;
                }
            }
        }else{
            ArrayList<Integer> sumList =new ArrayList();
            for (int j = 0; j < col; j++) {
                int sumRow =(int) Math.pow(arr[rowNum][j]+tempArr[rowNum-1][j],2);
                sumList.add(sumRow);
            }
            int min =  sumList.get(0);
            index =0;
            for (int i = 0; i < sumList.size(); i++) {
                if(sumList.get(i)<min){
                    min = sumList.get(i);
                    index =i;
                }
            }
        }
        return index;
    }
    public static void initializeTempArray(){
        tempArr =new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                tempArr[i][j] = 0;
            }
        }
    }
    public static void sortArrays(){
        for (int i = 0; i < row-1; i++)
            for (int j = 0; j < row-i-1; j++)
                if (rowsSum[j] < rowsSum[j+1])
                {
                    int [] temp_arr =new int[col];
                    for (int k = 0; k < col; k++) {
                        temp_arr[k]=arr[j][k];
                    }
                    for (int k = 0; k < col; k++) {
                        arr[j][k]=arr[j+1][k];
                        arr[j+1][k] = temp_arr[k];
                    }
                    int temp = rowsSum[j];
                    rowsSum[j] = rowsSum[j+1];
                    rowsSum[j+1] = temp;
                }
    }
}
