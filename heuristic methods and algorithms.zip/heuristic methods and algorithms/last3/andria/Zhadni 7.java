package Lab7;

public class Zhadni {
    private int n;
    private Integer[][] matrix;
    Individual shortWay;



    public Zhadni(int n, Integer[][] matrix){
        this.n = n;
        this.matrix = matrix;

        System.out.println("Жадный алгоритм");
        System.out.println("Мтрица");
        for (var lain: matrix){
            Lab.MyShowArr(lain);
        }
        System.out.println();

        shortWay = findSimple(0);
        System.out.println(shortWay);
        for(int i = 1; i < n; i++){
            Individual temp = findSimple(i);
            System.out.println(temp);
            if(temp.getFunctionValue()< shortWay.getFunctionValue()){
                shortWay = temp;
            }
        }
        System.out.println();
    }

    public Individual getShortWay() {
        return shortWay;
    }

    private Individual findSimple(int start){
        int[] arr = new int[n+1];
        int currentLength = 1;

        arr[0] = start;
        for(int i = 1; i<n;i++){
            Integer jMin = null;
            for(int j = 1; j<n; j++){
                boolean isContain = false;
                for(int k = 0; k<currentLength;k++){
                    if (arr[k] == (arr[i-1]+j)%n) {
                        isContain = true;
                        break;
                    }
                }
                if(!isContain){
                    if(jMin == null){
                        jMin = (arr[i-1]+j)%n;
                    }else if(matrix[arr[i-1]][(arr[i-1]+j)%n] < matrix[arr[i-1]][jMin]){
                        jMin = (arr[i-1]+j)%n;
                    }
                }

            }
            arr[i] = jMin;
            currentLength++;
        }
        arr[n] = start;


        return new Individual(matrix, arr);
    }
}
