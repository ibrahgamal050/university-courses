import java.util.ArrayList;
import java.util.Comparator;

public class Main {

    public static int MyRandom(int min, int max) throws Exception {
        if(min == max){
            return min;
        }
        if(min > max){
            throw new Exception("не правильные параметры");
        }
        return (int)Math.round(Math.random()*(max-min))+min;
    }

    public static int[] RandomArr(int length, int min, int max) throws Exception {
        int[] arr = new int[length];

        for(int i = 0; i < length; i++){
            arr[i] = Main.MyRandom(min, max);
        }

        return arr;
    }

    public static void MyShowArr(int[] arr){
        System.out.print("[ ");

        for(var elem: arr){
            System.out.print(elem+ " ");
        }
        System.out.print("]\n");
    }

    public static void main(String[] args) throws Exception {

        int m = 10  ;// количество заданий //الطول
        int n = 4  ;// кол-во процессоров
        int t1 = 10  ;// min
        int t2 = 19  ;// max
        int z = 6 ; // кол-во особей в нач популяции
        int k = 5  ;// повтор лучших особей
        int fraction = 256;
        float pk = (float) 0.90;// вероятность кроссовера
        float pm = (float) 1;// вероятность мутации


        GenetikAlg alg = new GenetikAlg(m,n,t1,t2,z,k, pk, pm,fraction);


        System.out.println(alg.start() + " - решение");
    }
}

class GenetikAlg{
    private int[][] valueArr;
    private Generation_ generation;
    private int lastBest;
    private int m;
    private int n;
    private int z;
    private int k;
    private int numbGen = 1;
    private int k_ = 0;
    private double probabilityCrosover;
    private double probabilityMuration;
    private int maxParam;



    public GenetikAlg(int m, int n, int t1, int t2, int z, int k, double probabilityCrosover, double probabilityMuration, int maxParam) throws Exception {
        this.m = m;
        this.n = n;
        this.z = z;
        this.k = k;

        this.probabilityCrosover = probabilityCrosover;
        this.probabilityMuration = probabilityMuration;
        this.maxParam = maxParam;
        valueArr = new int[n][];
        for(int i = 0; i < valueArr.length; i++){
            valueArr[i] = Main.RandomArr(m,t1,t2);
        }

        generation = new Generation_(valueArr, m,n,z,maxParam);
    }

    public int start() throws Exception {
        System.out.println("Мтрица");
        for (var lain: valueArr){
            Main.MyShowArr(lain);
        }
        System.out.println();

        while(k_ < k){
            choosePair();
            int bestNow = generation.getbest();
            if(bestNow == lastBest){
                k_++;
            }else{
                k_ = 0;
                lastBest = bestNow;
            }
            numbGen++;
            System.out.println(generation);
            generation.createNextGeneration();
        }
        System.out.println();
        System.out.println("лучшее поколение " + numbGen);
        System.out.println(generation);
        return lastBest;
    }



    public void choosePair() throws Exception {
        System.out.println();
        System.out.println("Поколение "+ numbGen);
        System.out.println("Родители");
        System.out.println(generation);
        int z_ = z;

        for(int i = 0; i < z; i++){
            for(int j = i+1; j < z; j++){
                double left = (z-j+(z-i-1)*(z-i-2)*1.0/2);

                if(z_ > 0 && Math.random() < (z_)/left){
                    System.out.println();
                    System.out.println("Пара " + i + " " + j);
                    comparator(i,j);
                    z_--;
                }
            }
        }
    }

    public void mutator(int[] arr) throws Exception {
        int pos = Main.MyRandom(0,arr.length-1);

        System.out.print(arr[pos] + " ");
        int[] bits = new int[2];

        bits[0] = Main.MyRandom(0,7);
        bits[1] = Main.MyRandom(0,7);
        if(bits[1] == bits[0]){
            bits[1] = (bits[1]+1)%8;
        }
        for(var bit: bits){
            System.out.print("Бит " + bit + " ");
            if((arr[pos]/(int)Math.pow(2,bit)) % 2  == 1){
                arr[pos]-=(int)Math.pow(2,bit);
            }else{
                arr[pos]+=(int)Math.pow(2,bit);
            }
        }
        System.out.print(arr[pos]);
        System.out.println();
    }

    public void comparator(int parentId1, int parentId2) throws Exception {
        if(parentId1 == parentId2 || parentId1 >= z || parentId2 >= z){
            throw new Exception("не правильные параметры");
        }
        int[] parent1 = generation.get(parentId1).getParameters();
        int[] parent2 = generation.get(parentId2).getParameters();
        Main.MyShowArr(parent1);
        Main.MyShowArr(parent2);
        int border1 = Main.MyRandom(0, m-1);
        int border2;
        if(border1 == 0){
            border2 = Main.MyRandom(border1+1, m-1);
        } else {
            border2 = Main.MyRandom(border1+1, m);
        }
        int[] child1 = new int[m];
        int[] child2 = new int[m];

        System.out.println("Барьеры " + border1 + " " + border2);
        for(int i = 0; i < border1 ; i++){
            child1[i] = parent1[i];
            child2[i] = parent2[i];
        }
        for(int i = border1; i < border2 ; i++){
            child1[i] = parent2[i];
            child2[i] = parent1[i];
        }
        for(int i = border2; i < m ; i++){
            child1[i] = parent1[i];
            child2[i] = parent2[i];
        }
        System.out.println("Дети");
        Main.MyShowArr(child1);
        Main.MyShowArr(child2);
        if(Math.random() < probabilityMuration){
            mutator(child1);
            System.out.println("Ребенок" + parentId1 + "" + parentId2 +" после мутации");
            Main.MyShowArr(child1);
        }
        if(Math.random() < probabilityMuration){
            mutator(child2);
            System.out.println("Ребенок" + parentId2 + "" + parentId1 +" после мутации");
            Main.MyShowArr(child2);
        }
        Individual iСhild1 = new Individual(valueArr, child1, n, maxParam);
        Individual iСhild2 = new Individual(valueArr, child2, n, maxParam);
        System.out.println("Загруженность");
        System.out.println(generation.get(parentId1).getMaxWorkload() + " Максимальная загруженность родителя" + parentId1);
        System.out.println(generation.get(parentId2).getMaxWorkload() + " Максимальная загруженность родителя" + parentId2);
        System.out.println(iСhild1.getMaxWorkload() + " Максимальная загруженность рекбенка" + parentId1 + "" + parentId2);
        System.out.println(iСhild2.getMaxWorkload() + " Максимальная загруженность рекбенка" + parentId2 + "" + parentId1);
        generation.add(iСhild1);
        generation.add(iСhild2);
    }

}

class Generation_{
    private ArrayList<Individual> individuals = new ArrayList<>();
    private int z;

    public Generation_(int[][] valueArr, int m, int n, int z, int maxParam) throws Exception {
        this.z = z;

        for(int i = 0; i < z; i++){
            individuals.add(new Individual(valueArr, Main.RandomArr(m, 0, maxParam), n, maxParam));
        }
    }

    public Individual get(int i) throws Exception {
        if(i<0 || i >= individuals.size()){
            throw new Exception("Вышли за границы массива особей");
        }

        return individuals.get(i);
    }

    public void add(Individual individual){
        individuals.add(individual);
    }

    public void createNextGeneration(){
        individuals.sort(new Comparator<Individual>() {
            @Override
            public int compare(Individual o1, Individual o2) {
                if(o1.getMaxWorkload() > o2.getMaxWorkload()){
                    return -1;
                } else if(o1.getMaxWorkload() == o2.getMaxWorkload()){
                    return 0;
                } else {
                    return 1;
                }
            }
        });

        while(individuals.size() > z){
            individuals.remove(0);
        }
    }

    public int getbest(){
        int minI = 0;
        int size = individuals.size();

        for(int i = 1; i < size; i++){
            if(individuals.get(i).getMaxWorkload() < individuals.get(minI).getMaxWorkload()){
                minI = i;
            }
        }

        return individuals.get(minI).getMaxWorkload();
    }

    @Override
    public String toString() {
        String out = "[\n";

        for(var individ: individuals ){
            out += "\t" + individ.toString() +"\n";
        }
        out += "]";

        return out;
    }
}

class Individual{
    private int[] parameters;
    private int[] workload;
    private int maxWorkload;

    public Individual(int[][] valueArr, int[] parameters, int n, int maxParam){
        this.parameters = new int[parameters.length];
        workload = new int[n];

        for(int i = 0; i < n; i++){
            workload[i] = 0;
        }
        for(int i = 0; i < parameters.length; i++){
            this.parameters[i] = parameters[i];

            for(int j = 1; j <= n; j++){
                if(this.parameters[i]<=maxParam*j*1.0/n){
                    workload[j-1] += valueArr[j-1][i];
                    break;
                }
            }
        }
        int maxI = 0;

        for(int i = 1; i < workload.length; i++){
            if(workload[i] > workload[maxI]){
                maxI = i;
            }
        }
        maxWorkload = workload[maxI];
    }

    public int[] getParameters(){
        int[] sendedArr = new int[parameters.length];

        for(int i = 0; i < parameters.length; i++){
            sendedArr[i] = parameters[i];
        }

        return sendedArr;
    }

    public int getMaxWorkload(){

        return maxWorkload;
    }

    @Override
    public String toString() {
        String out = "[ ";

        for(var elem: parameters){
            out += elem+ " ";
        }
        out += "] Значение целевой функции = " + getMaxWorkload();

        return out;
    }



}