package com.example.lab_3;
import java.util.*;
public class Test {
    public static boolean userExist(String[] users, String user) {
        boolean flag = false;
        for (int i = 0; i < users.length; i++) {
            if (users[i].equals(user)) {
                flag = true;
            }
        }
        return flag;
    }

    public static int getIndex(String[] users, String user) {
        return Arrays.asList(users).indexOf(user);
    }

    public static void printVectorO(Vector<Integer> O) {
        int count = 1;
        System.out.println("Уровни конфиденциальности Объектов (O) : ");
        for (int i = 0; i < O.size(); i++) {
            if (O.get(i) == 3) {
                System.out.println("Объект " + count++ + " : " + "Совершенно секретно");
            } else if (O.get(i) == 2) {
                System.out.println("Объект " + count++ + " : " + "Секретно");
            } else if (O.get(i) == 1) {
                System.out.println("Объект " + count++ + " : " + "Открытые данные");
            }
        }
    }

    public static void printVectorS(Vector<Integer> S,String[] users) {
        System.out.println("Уровни допуска пользователей (S) : ");
        for (int i = 0; i < S.size(); i++) {
            if (S.get(i) == 1) {
                System.out.println(users[i] + " : " + "Совершенно секретно");
            } else if (S.get(i) == 2) {
                System.out.println(users[i] + " : " + "Секретно");
            } else if (S.get(i) == 3) {
                System.out.println(users[i] + " : " + "Открытые данные");
            }
        }
    }

    public static void checkOperation(Vector<Integer> S,Vector<Integer> O,String op ,String[] users, String user) {
        Scanner sc = new Scanner(System.in);
        int number;
        int userIndex = getIndex(users, user);
        int choice; 
       
        switch (op) {
            case "request":
                System.out.println("К какому объекту хотите осуществить доступ ? ");
                choice = sc.nextInt();
                for(int i=0;i<S.size();i++) {
                    if (O.get(choice) <= S.get(i)) {
                        System.out.println("Операция прошла успешно.");
                        break;
                    } if(O.get(choice) != S.get(i)) {
                        System.out.println("Отказ в выполнении операции.Недостаточно прав.");
                        break;
                    }
                }
                break;
            case "quit":
           
               System.out.println("Работа пользователя"+" завершена. До свидания.");
                mainMenu(users, S,O);

                break;
        }
    }
    public static void printPermissions ( Vector<Integer> S,Vector<Integer> O, String[] users, String user){
        int userIndex = getIndex(users, user);
        System.out.println("Перечень доступных объектов : ");
        for(int i=0;i<O.size();i++) {
            if (S.get(userIndex) == O.get(i)) {
                System.out.println("Объект_" +(i+1));
            }
        }
    }
    public static void mainMenu (String[]users, Vector<Integer> S,Vector<Integer> O){
        Scanner sc = new Scanner(System.in);
        String op;
        String user;
        
        System.out.println("User : ");
        user = sc.nextLine();
        if (userExist(users, user)) {
            System.out.println("Идентификация прошла успешно, добро пожаловать в систему");
        } else System.out.println("Not found!!");
        printPermissions(S,O, users, user);
        while (true) {
            System.out.println("Жду ваших указаний > ");
            op = sc.nextLine();
          
            checkOperation(S,O,op, users, user);
        }
    }
    public static void main (String[]args){
        String[] users = {"joe", "hima", "max"};
        Vector<Integer> O = new Vector<Integer>();
        Vector<Integer> S = new Vector<Integer>();
        for (int i = 0; i < 4; i++) {
            O.add((int) ((Math.random() * 3) + 1));
        }
        for (int i = 0; i < 3; i++) {
            S.add((int) ((Math.random() * 3) + 1));
        }
        System.out.println(O);
        printVectorO(O);
        System.out.println(S);
        printVectorS(S, users);
       
        mainMenu(users,S,O);
        
        
    }
}