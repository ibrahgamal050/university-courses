import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class RSA {
    public static int p = 3; //17
    public static int q = 11; //41
    public static int kb = generatePrivateKey(p,q);

    public static int publicKey = generatePublicKey(p,q);
    public static int privateKey = generatePrivateKey(p,q);
    public static int eiler = generatePrivateKey(p,q);
    public static int N = generatePublicKey(p,q);
    public static char alphabets[] = new char[] {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T',
            'U','V','W','X','Y','Z'};
    public static String message,decryptedMessage;
    public static int[] encryptedMessage;
    public static int generatePublicKey(int p,int q){
        return p*q;
    }
    public static int generatePrivateKey(int p,int q){
        return (p-1)*(q-1);
    }
    public static boolean isOne() {
        for (int i = 2; i < eiler; i++) {
            if (gcd(i, eiler) != 1) {
                return false;
            }
        }
        return true;
    }
    
    public static int gcd(int a, int b) {
        if (b == 0) {
            return a;
        }
        return gcd(b, a % b);
    }
    
    public static int[] encryptMessage(String message, int N, int Kb) {
        int encryptedNumber[] = new int[message.length()];
        for (int i = 0; i < message.length(); i++) {
            for (int j = 0; j < alphabets.length; j++) {
                if (message.charAt(i) == alphabets[j]) {
                    encryptedNumber[i] = modularExponentiation(j + 1, Kb, N);
                }
            }
        }
        return encryptedNumber;
    }
    
    public static int modularExponentiation(int base, int exponent, int modulus) {
        if (modulus == 1) {
            return 0;
        }
        int result = 1;
        base = base % modulus;
        while (exponent > 0) {
            if (exponent % 2 == 1) {
                result = (result * base) % modulus;
            }
            exponent = exponent >> 1;
            base = (base * base) % modulus;
        }
        return result;
    }
    
    
    public static String decryptMessage(int[] encryptedNumber,char[] alphabets,int N,int kb){
        String Newstr = "";
        int o;
        for (int i = 0; i < encryptedNumber.length; i++) {
            if (encryptedNumber[i] == -1) { // skip non-capital letters
                continue;
            }
            o = (int) (Math.pow(encryptedNumber[i],kb)%N);
            // Perform modulo operation on o to ensure it's within bounds of the alphabets array
            o = (o - 1) % alphabets.length;
            // Handle negative result of modulo operation
            if (o < 0) {
                o += alphabets.length;
            }
            Newstr += alphabets[o];
        }
        return Newstr;
    
    
    }
    
    
    
    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int choice;
        System.out.println("Public key = " + publicKey);
        System.out.println("Private key = " + privateKey);
        System.out.println("1.Encrypt message");
        System.out.println("2.Decrypt message");
        System.out.println("3.Exit");
        do {
            System.out.println("Enter your choice : ");
            choice = sc.nextInt();
            switch (choice){
                case 1 :
                    
                        System.out.println("Enter message to be encrypted : ");
                        sc.nextLine();
                        message = sc.nextLine();
                        System.out.println("Message entered : " + message);
                        encryptedMessage = encryptMessage(message, N, kb);
                   
                    break;
                case 2 :
                    if(encryptedMessage==null){
                        System.out.println("Please encrypt a message first");
                    }
                    else {
                        decryptedMessage = decryptMessage(encryptedMessage,alphabets,N,kb);
                        System.out.println("Decrypted message " + decryptedMessage);
                    }
                    break;
                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Wrong choice!!");
                    break;
            }

        } while (choice!=3);
    }
}