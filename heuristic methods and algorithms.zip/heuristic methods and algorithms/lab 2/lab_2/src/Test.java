

import java.util.ArrayList;
import java.util.Collections;

public class Test {
    public static int row = 13 ; // m
    public static int col = 4 ; //n
    public static int t_min = 8; // t min
    public static int t_max = 21; // t max
    public static int[][] arr;
    public static int[][] tempArr;
    public static int[] rowsSum;

    public static void main(String[] args) {
        generateMatrix();
        getSumRows();
        System.out.println("sum the elements in the rows of the matrix");
        printArray(arr,rowsSum);
        sortArrays();
        System.out.println();
        System.out.println("after sorting the rows in descending order by amounts, the matrix will be : ");
        printArray(arr,rowsSum);
        initializeTempArray();
        mainOperation(); 
        System.out.println("After executing the algorithm, we get the table :");
        printArray(tempArr);
        System.out.println();
        System.out.print("max (f1(p1),f2(p2),f2(p3)) : ");
        printArray(getSumColumn(tempArr));
        System.out.println( " = "+Collections.max(getSumColumn(tempArr)));
        System.out.println( "-----------------------------------" );
        sortArrayss();
        System.out.println("after sorting the rows in descending order by amounts, the matrix will be : ");
        printArray(arr,rowsSum);
        initializeTempArray();
        mainOperation();
        System.out.println();
        System.out.println("-----------------------------------");
        System.out.println("After executing the algorithm, we get the table :");
        printArray(tempArr);
        System.out.println();
        System.out.print("max  : ");
        printArray(getSumColumn(tempArr));
        System.out.println( " = "+Collections.max(getSumColumn(tempArr)));

    }
    public static ArrayList<Integer> getSumColumn(int [][] temp){
       ArrayList<Integer> sumList =new ArrayList<>();
        for (int i = 0; i < col; i++) {
            int sum =0;
            for (int j = 0; j < row; j++) {
                sum+=temp[j][i];
            }
            sumList.add(sum);
        }
        return sumList ;
    }
    public static void minimizeTempArray(){
        for (int i = 0; i < col; i++) {
            for (int j = 1; j < row; j++) {
               int index =0;
               while (tempArr[index][i]!=0){
                   index++;
               }
               if(tempArr[j][i]!=0){
                   tempArr[index][i]= tempArr[j][i];
                   tempArr[j][i] =0;
               }
            }
        }
    }
    public static void mainOperation(){
        for (int i = 0; i < row; i++) {
            int index_min = getMinNum(i);
            tempArr [i][index_min] = arr[i][index_min];
        }
    }
    public static void printArray(int[][] arr){
        for (int i = 0; i < row; i++) {
            System.out.print("[");
            for (int j = 0; j < col; j++) {
                System.out.print(arr[i][j]);
                if(j != col-1) System.out.print(" , ");
            }
            System.out.print("]");
            System.out.println();
        }
    }
    public static void generateMatrix(){
        arr =new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                arr[i][j] = getRandomNumber();
            }
        }
    }
    public static void printArray(int[][] arr,int[] arrRes){
        for (int i = 0; i < row; i++) {
            System.out.print("[");
            for (int j = 0; j < col; j++) {
                System.out.print(arr[i][j]);
                if(j != col-1) System.out.print(" , ");
            }
            System.out.print(" ]");
            System.out.print("   sum = "+arrRes[i]);
            System.out.println();
        }
    }
    public static void getSumRows(){
        rowsSum = new int[row];
        for (int i = 0; i < row; i++) {
            int result =0 ;
            for (int j = 0; j < col; j++) {
                result += arr[i][j];
            }
            rowsSum[i]=result;
        }
    }
    public static int getRandomNumber(){
        return  (int)Math.floor(Math.random()*(t_max-t_min+1)+t_min);
    }
    public static void printArray(ArrayList<Integer> arr){
        System.out.print("[");
        for (int i = 0; i < arr.size(); i++) {
            System.out.print(arr.get(i));
            if(i < arr.size()-1) System.out.print(" , ");
        }
        System.out.print("]");
    }
    public static int getMinNum(int rowNum){
        ArrayList<Integer> sumList =new ArrayList<>();
        for (int i = 0; i < col; i++) {
            int sum=0;
            for (int j = 0; j < rowNum; j++) {
                sum += tempArr[j][i];
            }
            sumList.add(sum);
        }
        int sum = sumList.get(0)+arr[rowNum][0];
        int index =0;
        for (int i = 1; i < col; i++) {
            if(sumList.get(i)+arr[rowNum][i]<sum){
                sum = sumList.get(i)+arr[rowNum][i];
                index = i;
            }
        }
        return index;
    }
    public static void initializeTempArray(){
        tempArr =new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                tempArr[i][j] = 0;
            }
        }
    }
    public static void sortArrays(){
        for (int i = 0; i < row-1; i++)
            for (int j = 0; j < row-i-1; j++)
                if (rowsSum[j] < rowsSum[j+1])
                {
                    int [] temp_arr =new int[col];
                    for (int k = 0; k < col; k++) {
                        temp_arr[k]=arr[j][k];
                    }
                    for (int k = 0; k < col; k++) {
                        arr[j][k]=arr[j+1][k];
                        arr[j+1][k] = temp_arr[k];
                    }
                    int temp = rowsSum[j];
                    rowsSum[j] = rowsSum[j+1];
                    rowsSum[j+1] = temp;
                }
    }
    public static void sortArrayss(){
        for (int i = 0; i < row-1; i++)
            for (int j = 0; j < row-i-1; j++)
                if (rowsSum[j] > rowsSum[j+1])
                {
                    int [] temp_arr =new int[col];
                    for (int k = 0; k < col; k++) {
                        temp_arr[k]=arr[j][k];
                    }
                    for (int k = 0; k < col; k++) {
                        arr[j][k]=arr[j+1][k];
                        arr[j+1][k] = temp_arr[k];
                    }
                    int temp = rowsSum[j];
                    rowsSum[j] = rowsSum[j+1];
                    rowsSum[j+1] = temp;
                }
    }
}
