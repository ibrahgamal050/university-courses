from random import randint as rand
from random import sample

m = 10  # количество заданий
n = 5  # кол-во процессоров
t1 = 9  # min
t2 = 18  # max
z = 5  # кол-во особей в нач популяции
k = 5  # повтор лучших особей
fraction = 256

pk = 0.90 * 100  # вероятность кроссовера
pm = 0.90 * 100  # вероятность мутации


def create_individual(min_weight, max_weight, max_value, length):
    weights = [[] for _ in range(n)]

    for i in range(n):
        for _ in range(m):
            weights[i].append(rand(min_weight, max_weight))

    values = [rand(0, max_value) for _ in range(length)]

    return [weights, values]


def main():
    sum_generation = []

    count = 0
    gen_counter = 0

    individuals = []

    coef_list = []
    tmp_coef = (fraction) / n
    tmp_val = tmp_coef

    coef_list.append((0, round(tmp_val)))
    tmp_val *= 2

    for _ in range(1, n):
        coef_list.append((round((tmp_val - tmp_coef) + 1), round(tmp_val)))
        tmp_val += tmp_coef

    for _ in range(z):
        individuals.append(create_individual(t1, t2, fraction - 1, m))

    # for individ in individuals:
    #   print(individ[0])

    last_elem = list(coef_list[-1])
    last_elem[1] -= 1
    coef_list[-1] = tuple(last_elem)

    print("Промежутки:")
    print(coef_list)

    individual_matrix = [[] for i in range(z)]

    for i in range(len(individual_matrix)):
        for j in range(len(coef_list)):
            individual_matrix[i].append([])

    save_individuals = []

    while count < k:

        gen_counter += 1
        print("Поколение:", gen_counter, "----------------------------------------------------------------------------")

        for individ_n in range(z):

            print("Для", individ_n + 1, "особи")

            individual_matrix = [[] for i in range(z)]

            for i in range(len(individual_matrix)):
                for j in range(len(coef_list)):
                    individual_matrix[i].append([])

            child_weight_matrix = [[] for i in range(2)]

            for i in range(len(child_weight_matrix)):
                for j in range(len(coef_list)):
                    child_weight_matrix[i].append([])

            for i in range(z):
                for j in range(m):
                    for index, (min_v, max_v) in enumerate(coef_list):
                        if min_v <= individuals[i][1][j] <= max_v:
                            individual_matrix[i][index].append(individuals[0][0][index][j])

            # print(individual_matrix)

            print("Веса:")
            for individual in individuals[0][0]:
                print(individual)

            for index, individ in enumerate(individual_matrix, start=1):
                print()
                print("Особь", index)
                print(individuals[index - 1][1], end='')
                print("Max:", sum(max(individ, key=sum)))

            percent = rand(1, 100)
            crossover_individ = sample(range(1, z + 1), 2)
            while percent >= pk:
                crossover_individ = sample(range(1, z + 1), 2)
                percent = rand(1, 100)

            print()
            print("Кроссовер:", crossover_individ)

            position1 = rand(1, m - 1)
            position2 = rand(1, m - 1)
            while abs(position1 - position2) <= 2:
                position1 = rand(1, m - 2)
                position2 = rand(1, m - 2)

            if position1 > position2:
                position1, position2 = position2, position1

            # print("Барьер:")
            print("Барьер:", position1 + 1, position2 + 1)
            child_matrix = []
            child_matrix.append(
                individuals[crossover_individ[0] - 1][1][0:position1 + 1] + individuals[crossover_individ[1] - 1][1][
                                                                            position1 + 1:position2 + 1] +
                individuals[crossover_individ[0] - 1][1][position2 + 1:])
            child_matrix.append(
                individuals[crossover_individ[1] - 1][1][0:position1 + 1] + individuals[crossover_individ[0] - 1][1][
                                                                            position1 + 1:position2 + 1] +
                individuals[crossover_individ[1] - 1][1][position2 + 1:])

            print(child_matrix)

            child_weight_matrix = [[] for i in range(2)]

            for i in range(len(child_weight_matrix)):
                for j in range(len(coef_list)):
                    child_weight_matrix[i].append([])

            for i in range(2):
                for j in range(m):
                    for index, (min_v, max_v) in enumerate(coef_list):
                        if min_v <= child_matrix[i][j] <= max_v:
                            child_weight_matrix[i][index].append(individuals[0][0][index][j])

            min_index = 2
            min_max = fraction
            for index, individ in enumerate(child_weight_matrix, start=1):
                print()
                s = sum(max(individ, key=sum))
                if sum(max(individ, key=sum)) < min_max:
                    min_index = index - 1
                    min_max = sum(max(individ, key=sum))
                print("Ребёнок", index)
                print(child_matrix[index - 1], end='')
                print("Max:", sum(max(individ, key=sum)))

            # print(min_index, min_max)
            # min_child = child_matrix[min_index]
            # print(min_child)

            print()
            print("Выбрали ребенка", min_index + 1, "с результатом", min_max)
            min_child = child_matrix[min_index]
            print(min_child)

            for i in range(len(child_matrix)):
                position_v = rand(0, m - 1)
                percent = rand(1, 100)
                while percent >= pm:
                    position_v = rand(0, m - 1)
                    percent = rand(1, 100)

                # print(position_v)
                mutation = position_v + 1
                print()
                print("Мутировали в гене номер =", mutation)

                bin_value = str(bin(child_matrix[i][position_v]))[2:]

                position1 = rand(0, len(bin_value) - 1)
                position2 = rand(0, len(bin_value) - 1)
                while position1 == position2:
                    position1 = rand(0, len(bin_value) - 1)
                    position2 = rand(0, len(bin_value) - 1)

                if position1 > position2:
                    position1, position2 = position2, position1

                # print("до")
                print(child_matrix[i][position_v], bin_value)
                position = rand(0, len(bin_value) - 1)

                split_bin = [char for char in bin_value]
                split_bin[position1], split_bin[position2] = split_bin[position2], split_bin[position1]
                bin_value = ''.join(split_bin)
                # print("после")
                # print(bin_value)
                # print("добавили значение")
                value = int(bin_value, 2)
                print(value, bin_value)
                print(value)

                child_matrix[i][position_v] = int(bin_value, 2)

            # value = int(bin_value, 2)
            # print("после 2")
            # print(value)
            ####################################################################
            # min_child[position_v] = value

            # child_matrix[min_index] = min_child
            # min_index = 2
            # min_max = fraction

            child_weight_matrix = [[] for i in range(2)]

            for i in range(len(child_weight_matrix)):
                for j in range(len(coef_list)):
                    child_weight_matrix[i].append([])

            for i in range(2):
                for j in range(m):
                    for index, (min_v, max_v) in enumerate(coef_list):
                        if min_v <= child_matrix[i][j] <= max_v:
                            child_weight_matrix[i][index].append(individuals[0][0][index][j])

            print()
            print("Дети после мутации:")

            for index, individ in enumerate(child_weight_matrix, start=1):
                # print()
                s = sum(max(individ, key=sum))
                if sum(max(individ, key=sum)) < min_max:
                    min_index = index - 1
                    min_max = sum(max(individ, key=sum))
                print("Ребёнок", index)
                print(child_matrix[index - 1], end='')
                print("Max:", sum(max(individ, key=sum)))
                print()

            s1 = sum(max(child_weight_matrix[min_index], key=sum))
            s2 = sum(max(individual_matrix[min_index], key=sum))

            save_individuals.append((child_matrix[min_index], min_max))

            # if sum(max(child_weight_matrix[min_index], key=sum)) <= sum(max(individual_matrix[individ_n], key=sum)):
            #     individuals[individ_n] = individuals[individ_n][0], child_matrix[min_index]

            # print()

        ##########################################################################
        # вот тут с суммой разобраться
        # for index, individ in enumerate(individual_matrix, start=1):
        #         print()
        #         print("Individ", index)
        #         print(individuals[index-1][1], end='')
        #         save_individuals.append(individuals[index-1][1])
        #         print("Max:", sum(max(individ, key=sum)))

        print('Saved')
        # for index, individ in enumerate(individual_matrix, start=1):
        #         print(individuals[index-1][1], end='')
        #         print("Max:", sum(max(individ, key=sum)))

        if len(save_individuals) == z:
            for index, individ in enumerate(individual_matrix, start=1):
                print()
                print("Особь", index)
                print(individuals[index - 1][1], end='')
                s = sum(max(individ, key=sum))
                save_individuals.append((individuals[index - 1][1], sum(max(individ, key=sum))))
                print("Max:", sum(max(individ, key=sum)))

        print()

        for index, individ in enumerate(save_individuals):
            print(individ)

        print()
        print()
        save_individuals = sorted(save_individuals, key=lambda x: x[1])
        save_individuals = save_individuals[:z]

        for index, individ in enumerate(save_individuals):
            print(individ[0], "Sum:", individ[1])

        sum_tuple = set()

        for index, (individ, summary) in enumerate(save_individuals, start=1):
            print()
            print("Особь", index)
            print(individ, end='')
            sum_tuple.add(summary)
            print(sum_tuple)
            print("Max:", summary)

        sum_generation.append(min(sum_tuple))
        count += 1

        # print('123456789')
        for index, (individ, _) in enumerate(save_individuals):
            individuals[index][1] = individ
            print(individuals[index][1])

        if count > 1:
            if sum_generation[count - 1] != sum_generation[count - 2]:
                sum_generation = []
                count = 0

    print()
    print("Результат:")
    print(sum_generation)

    print("Нашли за", gen_counter, "поколения(-й)")


if __name__ == "__main__":
    main()
