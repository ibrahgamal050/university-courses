import java.math.BigInteger;

public class RSAKeyPairGenerator {
    public static void main(String[] args) {
        int p = 13;
        int q = 61;

        BigInteger n = BigInteger.valueOf(p).multiply(BigInteger.valueOf(q));
        BigInteger phiN = BigInteger.valueOf(p - 1).multiply(BigInteger.valueOf(q - 1));

        BigInteger e = BigInteger.valueOf(11); // Задайте значение e, взаимно простое с phiN

        BigInteger d = e.modInverse(phiN);

        System.out.println("Открытый ключ: (" + e + ", " + n + ")");
        System.out.println("Закрытый ключ: (" + d + ", " + n + ")");

        String message = "Ивано"; // Введите первые пять букв своей фамилии
        int[] messageNumbers = convertToNumbers(message);

        BigInteger[] encryptedMessage = encryptMessage(messageNumbers, e, n);

        System.out.print("Зашифрованное сообщение: ");
        for (BigInteger number : encryptedMessage) {
            System.out.print(number + " ");
        }
        System.out.println();
    }

    private static int[] convertToNumbers(String message) {
        int[] numbers = new int[message.length()];
        for (int i = 0; i < message.length(); i++) {
            char c = message.charAt(i);
            if (Character.isLetter(c)) {
                int index = Character.toUpperCase(c) - 'А' + 1;
                numbers[i] = index;
            }
        }
        return numbers;
    }

    private static BigInteger[] encryptMessage(int[] messageNumbers, BigInteger e, BigInteger n) {
        BigInteger[] encryptedMessage = new BigInteger[messageNumbers.length];
        for (int i = 0; i < messageNumbers.length; i++) {
            BigInteger number = BigInteger.valueOf(messageNumbers[i]);
            BigInteger encryptedNumber = number.modPow(e, n);
            encryptedMessage[i] = encryptedNumber;
        }
        return encryptedMessage;
    }
}
