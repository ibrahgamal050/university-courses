import java.util.*;

public class Main {
    
    public static void main(String[] args) {
        Func func = new Func();

        //func.CMP(6, 16, 10, 22);

        func.HDMT(6, 16, 10, 22);
    }
}

class Func {
    public List<List<Integer>> list = new ArrayList<List<Integer>>();

    public List<List<Integer>> CMP_Temp(List<Integer> works, int procCount) {
        List<List<Integer>> procs = new ArrayList<List<Integer>>();
        for (int i = 0; i < procCount; i++) {
            procs.add(new ArrayList<Integer>());
        }
        int min = Integer.MAX_VALUE;
        int summ;
        while (works.size() != 0) {
            int minInd = 0;
            for (int i = 0; i < procCount; ++i) {
                summ = 0;
                for (int el : procs.get(i)) {
                    summ += el;
                }
                if (summ == 0) {
                    minInd = i;
                    break;
                }
                if (summ < min) {
                    min = summ;
                    minInd = i;
                }
            }
            procs.get(minInd).add(works.get(0));
            int summ1 = 0;
            for (var el : procs.get(minInd)) {
                summ1 += el;
            }
            min = Integer.MAX_VALUE;
            works.remove(0);
        }
        return procs;
    }

    public void OFMT_Rec(List<Integer> works, int counter) {
        var c = counter;
        if (c > 1) {
            var r = CMP_Temp(works, 2);
            c--;
            OFMT_Rec(r.get(0), c);
            OFMT_Rec(r.get(1), c);
        }
        if (c == 1) {
            var r = CMP_Temp(works, 2);
            list.addAll(r);
        }
    }

    public List<List<Integer>> CMP(int n, int m, int a, int b) {
        int[][] matrix = new int[m][];
        System.out.println("=== Mtrix === ");
        for (int i = 0; i < m; i++) {
            matrix[i] = new int[n];
            Random rnd = new Random();
            int randNum = rnd.nextInt(b - a) + a;
            System.out.print("[ ");
            for (int j = 0; j < n; j++) {
                matrix[i][j] = randNum;
                System.out.print(matrix[i][j]);
                if(j != matrix[i].length-1){
                    System.out.print(" , ");}
            }
            System.out.print(" ] ");
            System.out.println();
            
        }
        Arrays.sort(matrix, (x, y) -> -Integer.compare(x[0], y[0]));
        System.out.println();
        System.out.println("=== Sorted Matrix: = == = == ");
        System.out.println();
        for (int i = 0; i < m; i++) {
             System.out.print("[ ");
            for (int j = 0; j < n; j++) {
                System.out.print(matrix[i][j] );
                if(j != matrix[i].length-1){
                    System.out.print(" , ");}
            }
            System.out.print("]");
            System.out.println();
        }
    
       

        List<Integer> works = new ArrayList<Integer>();
        for (int i = 0; i < m; i++) {
            works.add(matrix[i][0]);
        }
        works.sort(Collections.reverseOrder());
        System.out.print(" T= [ ");
        for (int i = 0; i < works.size(); i++) {
            System.out.print(works.get(i) + " ");
        }
        System.out.println("] ");

        // CMP

        var procs = CMP_Temp(works, n);
        int iteraror = 1;
        for (var proc : procs) {
            int summ = 0;
            System.out.println("№" + iteraror);
            for (var elem : proc) {
                System.out.print(elem + " ");
                summ += elem;
            }
            System.out.print("\t=: " + summ);
            System.out.println();
            iteraror++; 
        } 
        return procs;
    }
    public List<List<Integer>> HDMT(int n, int m, int a, int b) {
        if (n % 2 != 0) {
            System.out.println("Нечетное число процессов!");
            return null;
        }
    
        int[][] matrix = new int[m][];
        System.out.println("=== Matrix: = == = ==  ");
    
        for (int i = 0; i < m; i++) {
            matrix[i] = new int[n];
            Random rnd = new Random();
            int randNum = rnd.nextInt(b - a) + a;
            System.out.print("[ ");
            for (int j = 0; j < n; j++) {
                matrix[i][j] = randNum;
                System.out.print(matrix[i][j] );
                 if(j != matrix[i].length-1){
                    System.out.print(" , ");}
            }
            System.out.print(" ] ");
            System.out.println();
        }
    
        Arrays.sort(matrix, (x, y) -> -Integer.compare(x[0], y[0]));
        System.out.println("=== Sorted Matrix: = == = ==  ");
    
        for (int i = 0; i < m; i++) {
            System.out.print("[ ");
            for (int j = 0; j < n; j++) {
                System.out.print(matrix[i][j]) ;
                if(j != matrix[i].length-1){
                    System.out.print(" , ");}
            }
    
            System.out.println(" ]");
        }
    
        List<Integer> works = new ArrayList<>();
    
        for (int i = 0; i < m; i++) {
            works.add(matrix[i][0]);
        }
    
        works.sort(Collections.reverseOrder());
    
        //works = new ArrayList<>(Arrays.asList(15, 15, 14, 14, 14, 13, 13, 12, 11, 10, 10, 10, 10, 9, 9));
        System.out.print("T = [ ");
    
        for (int i = 0; i < works.size(); i++) {
            System.out.print(works.get(i) + " ");
        }
    
        System.out.println("]");
    
        // HDMT
        System.out.println("Решение: ");
        // First level
        System.out.println("First level ");
        List<List<Integer>> firstLevelProc = CMP_Temp(works, 2);
        int iterator = 1;
    
        for (List<Integer> proc : firstLevelProc) {
            System.out.println("№" + iterator);
    
            for (Integer elem : proc) {
                System.out.print(elem + " ");
            }
    
            System.out.println();
            iterator++;
        }
    
        // Second level
        System.out.println("Second level: ");
        List<List<Integer>> secondLevelProc1 = CMP_Temp(firstLevelProc.get(0), n / 2);
        List<List<Integer>> secondLevelProc2 = CMP_Temp(firstLevelProc.get(1), n / 2);
        iterator = 1;
    
        for (List<Integer> proc : secondLevelProc1) {
            System.out.println("№" + iterator);
    
            for (Integer elem : proc) {
                System.out.print(elem + " ");
            }
    
            System.out.println();
            iterator++;
        }
    
        for (List<Integer> proc : secondLevelProc2) {
            System.out.println("№" + iterator);
    
            for (Integer elem : proc) {
                System.out.print(elem + " ");
            }
    
            System.out.println();
            iterator++;
        }
    
        List<List<Integer>> result = new ArrayList<>();
        result.addAll(secondLevelProc1);
        result.addAll(secondLevelProc2);
        iterator = 1;
    
        System.out.println("Решение: ");
    
        for (List<Integer> res : result) {
            int summ = 0;
            System.out.println("№" + iterator);
    
            for (int elem : res) {
                System.out.print(elem + " ");
                summ += elem;
                }
                System.out.print("\t=: " + summ);
                System.out.println();
                iterator++;
                }
                return result;
            
        }
    
}