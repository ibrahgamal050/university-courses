import java.util.ArrayList;

public class Test {
    public static int row = 10 ; // m
    public static int col = 4 ; //n
    public static int t_min = 8; // t min
    public static int t_max = 18; // t max
    public static int[][] arr;
    public static int[][] tempArr;
    public static int[] rowsMin;
    public static int barrierPos =0;
    public static double barrier;

    public static void main(String[] args) {
        generateMatrix();
        getMinRow();
        System.out.println("min the elements in the rows of the matrix");
        printArray(arr, rowsMin);
        sortArrays();
        System.out.println();
        System.out.println("after sorting the rows in descending order by amounts, the matrix will be : ");
        printArray(arr, rowsMin);
        initializeTempArray();
        mainOperation();
        System.out.println();
        System.out.println("After executing the algorithm, we get the table :");
        printArray(tempArr);
        System.out.println();
        System.out.print("max : ");
        System.out.println( " = "+getMax());

    }
    public static int getMax(){
        int max = tempArr[tempArr.length-1][0] ;
        for (int i = 0; i < col; i++) {
            int num = tempArr[tempArr.length-1][i];
            if(max< num){
                max = num;
            }
        }

        return max ;
    }


    public static void mainOperation(){
        barrier = Math.ceil((float) getSumMatrix(rowsMin)/col);
        boolean afterBarrier = false;
        System.out.println(barrier);
        int i =0;
        while (i< row) {
            int index_min = getMinNum(i);
            int index_min_Barrier = 0 ;
            if(afterBarrier) index_min_Barrier =getMinNumAfterBarrier(i);
            for (int j = 0; j < col; j++) {
                if(!afterBarrier && j == index_min||afterBarrier && j == index_min_Barrier){
                    if(!afterBarrier && j == index_min){
                        if(i != 0 && arr[i][index_min] + tempArr [i-1][index_min] > barrier) {
                            afterBarrier =true;
                            index_min_Barrier = getMinNumAfterBarrier(i);
                            barrierPos =i;
                            System.out.println(barrierPos);
                            i--;
                            break;

                        }
                        if(i==0) tempArr [i][j] = arr[i][index_min];
                        else if (!afterBarrier)
                            tempArr [i][index_min] = arr[i][index_min]+ tempArr [i-1][index_min];
                    }if(afterBarrier && j == index_min_Barrier) {
                        tempArr[i][index_min_Barrier] = arr[i][index_min_Barrier] + tempArr[i - 1][index_min_Barrier];
                    }
                }else{
                    if(i!=0) tempArr [i][j] = tempArr [i-1][j];
                }
            }
            i++;
        }
    }
    public static int  getMinNum(int rowNum){
        int index = 0;
        double min = arr[rowNum][0] ;
        for (int i = 1;i < col; i++) {
            if(min > arr[rowNum][i]){
                min = arr[rowNum][i];
                index=i;
             }
        }
        return index;
    }
    public static int getMinNumAfterBarrier(int rowNum){
        int[] temp =new int[col];
        for (int i = 0; i < col; i++) {
            temp[i]= arr[rowNum][i]+tempArr[rowNum-1][i];
        }
        int index =0;
        int min = temp[0] ;
        for (int i = 1; i < col; i++) {
            if(min>temp[i]){
                min = temp[i];
                index =i;
            }
        }

        return index;
    }





    public static void printArray(int[][] arr){
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if(barrierPos!=0&&i==0&&j==0) System.out.println("barrier = "+barrier);
                if(barrierPos!=0&&barrierPos==i&&j==0) 
                // System.out.println("start from " +barrierPos);
                if(j==0)System.out.print("[");
                System.out.print(arr[i][j]);
                if(j != col-1) System.out.print(" , ");
            }
            System.out.print("]");
            System.out.println();
        }
    }
    public static void generateMatrix(){
        arr =new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                arr[i][j] = getRandomNumber();
            }
        }
       //arr =new int[][]{{14,11,14,11},{13,14,14,14},{10,12,11,10},{13,11,11,13},{12,12,11,11},{13,13,10,11},{11,12,13,11},{14,13,11,12},{11,11,12,12},{13,14,14,14},{10,14,14,14}};
        //arr = new int [][]{{18,21,16},{20,18,20},{18,18,11},{20,13,20},{20,12,17},{21,19,16},{17,11,14},{16,17,21},{12,13,20},{21,21,12},{19,17,11}};
       //arr =new int[][]{{13,14,14,14},{13,14,14,14},{13,11,11,13},{12,12,11,11},{11,12,13,11},{14,13,11,12},{11,11,12,12},{14,11,14,11},{10,12,11,10},{13,13,10,11},{10,14,14,14}};
    }
    public static void printArray(int[][] arr,int[] arrRes){
        for (int i = 0; i < row; i++) {
            System.out.print("[");
            for (int j = 0; j < col; j++) {
                System.out.print(arr[i][j]);
                if(j != col-1) System.out.print(" , ");
            }
            System.out.print(" ]");
            System.out.print("   min = "+arrRes[i]);
            System.out.println();
        }
    }
    public static void getMinRow(){
        rowsMin = new int[row];
        for (int i = 0; i < row; i++) {
            int min = arr[i][0] ;
            for (int j = 0; j < col; j++) {
                if(min>arr[i][j]) min = arr[i][j];
            }
            rowsMin[i]=min;
        }
    }
    public static int  getRandomNumber(){
        return  (int)Math.floor(Math.random()*(t_max-t_min+1)+t_min);
    }
    public static void printArray(ArrayList<Integer> arr){
        System.out.print("[");
        for (int i = 0; i < arr.size(); i++) {
            System.out.print(arr.get(i));
            if(i < arr.size()-1) System.out.print(" , ");
        }
        System.out.print("]");
    }
    public static void initializeTempArray(){
        tempArr =new int[row][col];
        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                tempArr[i][j] = 0;
            }
        }


    }
    public static void sortArrays(){
        for (int i = 0; i < row-1; i++)
            for (int j = 0; j < row-i-1; j++)
                if (rowsMin[j] < rowsMin[j+1])
                {
                    int [] temp_arr =new int[col];
                    for (int k = 0; k < col; k++) {
                        temp_arr[k]=arr[j][k];
                    }
                    for (int k = 0; k < col; k++) {
                        arr[j][k]=arr[j+1][k];
                        arr[j+1][k] = temp_arr[k];
                    }
                    int temp = rowsMin[j];
                    rowsMin[j] = rowsMin[j+1];
                    rowsMin[j+1] = temp;
                }
    }
    public static int getSumMatrix(int[] list ){
        int sum =0;
        for (int i = 0; i < list.length; i++) {
            sum+=list[i];
        }
        return sum;
    }
}
